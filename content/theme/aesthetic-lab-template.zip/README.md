# Aesthetic Lab Template — thème Shopify (Online Store 2.0)

Squelette de boutique prêt à personnaliser. Tous les médias (photos, vidéos, logos presse, visuels produits) ont été retirés et remplacés par des aplats gris neutres. Les textes, les sections, la page produit à blocs, le pop-up quiz, le drawer panier et les réglages sont conservés : il suffit de remplacer les éléments par les vôtres.

## Installation (5 minutes)

1. Zippez ce dossier si ce n'est pas déjà fait : le zip doit contenir `assets/ config/ layout/ locales/ sections/ snippets/ templates/` à sa racine.
2. Shopify admin → Boutique en ligne → Thèmes → Ajouter un thème → Importer un fichier zip.
3. Ou avec le CLI : `shopify theme push --store VOTRE-BOUTIQUE.myshopify.com --unpublished` depuis ce dossier.
4. Ouvrez l'éditeur de thème : chaque image ou vidéo grise est un emplacement à remplir via le sélecteur d'image/vidéo de la section.

## À remplacer en priorité

- Réglages du thème → Marque : wordmark (nom de la marque), favicon, e-mail support (`support@yourbrand.com` par défaut).
- Réglages du thème → Key links : page quiz, page résultats, collection principale, produit principal.
- Section Hero : vidéo + affiche (poster). Les fichiers `assets/placeholder-hero*.{mp4,webp}` sont des aplats de couleur, remplacez-les via l'éditeur.
- Sections Logos presse / avis / avant-après : toutes les images sont vides, choisissez les vôtres.
- Footer : ligne du bas (`Your Brand · Your Country · support@yourbrand.com`).
- `templates/product.*.json` : exemples de pages produit (jawliner, bracelet, patch, tape, peptide). Supprimez ceux dont vous n'avez pas besoin ou dupliquez-les pour vos produits.

## Produits

`import/products.csv` est un exemple de fichier d'import (Produits → Importer). Adaptez les colonnes Handle, Title, Body, Price, Compare At Price et les métachamps.

Métachamps lus par la page produit, namespace `aesthetic_lab` : `eyebrow` (texte), `promise` (texte), `category_code` (texte), `badge` (texte), `benefits` (liste de textes), `inside` (texte riche). À créer une fois dans Paramètres → Données personnalisées → Produits.

## Pages et menus à créer dans l'admin

- Pages : Assessment (`page.assessment`), Assessment results (`page.assessment-results`), About (`page.about`), FAQ (`page.faq`), Support (`page.support`).
- Collections : une collection principale (ex. `protocols`) et vos collections de produits.
- Menus : `main-menu` + menus du footer.
- Blog : un blog nommé Journal si vous utilisez la section Journal.

## Fichiers techniques

- `assets/base.css` : tout le design system (palette, typographie, cartes, boutons, animations).
- `assets/theme.js` : navigation, drawer panier (ajax), sliders avant/après, vidéos lazy, révélations GSAP.
- `assets/assessment-data.js` : questions et logique du quiz. `assets/face-scan.js` : scan visage (optionnel).
- `snippets/product-block.liquid` + `sections/main-product.liquid` : système de blocs de la page produit, ordre libre dans l'éditeur.

## Médias conservés

Seuls restent : `rating-logo.png` (étoiles de notation génériques), `pay-*.svg` (logos de paiement) et les aplats gris `placeholder-*.webp`, `qc-*.webp`, `gift-*.webp`, `placeholder-hero*.mp4`.
