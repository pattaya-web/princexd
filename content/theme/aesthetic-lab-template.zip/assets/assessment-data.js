/* Aesthetic Lab assessment engine.
   Eight questions. Weights are summed per category; the ranking gives the three highest-impact areas.
   The commitment and goal questions (both surface in the profile summary).
   State is persisted under the aesthetic* keys (localStorage + sessionStorage) for product page continuity and analytics. */
window.AL_ASSESSMENT = {
  categories: [
    { id: "face", name: "Face", handle: "face-protocol" },
    { id: "skin", name: "Skin", handle: "clear-skin-protocol" },
    { id: "hair", name: "Hair", handle: "hair-optimization-guide" },
    { id: "physique", name: "Physique", handle: "aesthetic-physique-protocol" },
    { id: "grooming", name: "Grooming", handle: "complete-grooming-system" },
    { id: "style", name: "Style", handle: "personal-style-system" }
  ],
  why: {
    face: "Facial framing, from brow shape to facial hair to definition, sets how balanced and defined your features read to other people.",
    skin: "Skin quality is one of the first things people register up close. Clarity, tone and texture shape how healthy and well-kept you appear.",
    hair: "Hair strongly frames the face and can significantly influence perceived facial balance and overall presentation.",
    physique: "Body composition and posture define your silhouette and are among the most noticeable signals from a distance.",
    grooming: "Grooming details such as neckline, brows, nails and scent are small on their own but compound into a sharper, more intentional presentation.",
    style: "Fit, proportion and a coherent wardrobe change how you read from a distance and how put-together you seem before you say a word."
  },
  rankCopy: [
    "Based on your answers, this is currently one of your highest-impact opportunities.",
    "Your answers place this as a strong secondary opportunity that compounds with your primary focus.",
    "A supporting area that reinforces the first two once they are in motion."
  ],
  rankLabels: ["Highest-impact area", "Secondary opportunity", "Supporting opportunity"],
  matchLabels: ["High priority", "Strong priority", "Supporting priority"],
  exitOption: { question: "age", option: "u18" },
  questions: [
    { id: "focus", eyebrow: "Focus", question: "What would change the most about how you look, starting tomorrow?", options: [
      { id: "jaw", label: "Jawline & face", w: { face: 5, grooming: 1 } },
      { id: "skin", label: "Skin", w: { skin: 5 } },
      { id: "hair", label: "Hair", w: { hair: 5 } },
      { id: "physique", label: "Physique", w: { physique: 5 } },
      { id: "style", label: "Style & grooming", w: { style: 3, grooming: 3 } },
      { id: "all", label: "All of it", w: { grooming: 2, hair: 1, skin: 1, style: 1, face: 1 } }
    ] },
    { id: "age", eyebrow: "Age", question: "How old are you?", options: [
      { id: "u18", label: "Under 18", w: {} },
      { id: "18-24", label: "18 to 24", w: { skin: 1 } },
      { id: "25-34", label: "25 to 34", w: { grooming: 1 } },
      { id: "35-44", label: "35 to 44", w: { skin: 2, face: 1 } },
      { id: "45+", label: "45 and over", w: { skin: 2, face: 1, physique: 1 } }
    ] },
    { id: "routine", eyebrow: "Skin", question: "Your skin routine today, honestly.", options: [
      { id: "none", label: "Nothing", w: { skin: 4 } },
      { id: "soap", label: "Water and soap", w: { skin: 3 } },
      { id: "basic", label: "Cleanser and moisturizer", w: { skin: 1 } },
      { id: "full", label: "Full routine with actives", w: { face: 1 } }
    ] },
    { id: "haircut", eyebrow: "Hair", question: "Your last haircut. How did you ask for it?", options: [
      { id: "photo", label: "I showed a photo", w: { hair: 1 } },
      { id: "words", label: "I described it in words", w: { hair: 2 } },
      { id: "barber", label: "I let the barber decide", w: { hair: 4 } },
      { id: "self", label: "I cut it myself", w: { hair: 4, grooming: 1 } }
    ] },
    { id: "training", eyebrow: "Training", question: "How many times a week do you train?", options: [
      { id: "0", label: "Zero", w: { physique: 4 } },
      { id: "1-2", label: "1 to 2", w: { physique: 3 } },
      { id: "3-4", label: "3 to 4", w: { physique: 1, style: 1 } },
      { id: "5+", label: "5 or more", w: { style: 1, grooming: 1 } }
    ] },
    { id: "photo", eyebrow: "Photos", question: "In a group photo, what do you check first on yourself?", options: [
      { id: "skin", label: "My skin", w: { skin: 3 } },
      { id: "jaw", label: "My jawline", w: { face: 3 } },
      { id: "hair", label: "My hair", w: { hair: 3 } },
      { id: "body", label: "My body", w: { physique: 3 } },
      { id: "avoid", label: "I avoid photos of myself", w: { grooming: 2, face: 1, skin: 1 } }
    ] },
    { id: "budget", eyebrow: "Budget", question: "What would you put into the next 90 days?", options: [
      { id: "u50", label: "Under $50", w: {} },
      { id: "50-150", label: "$50 to $150", w: {} },
      { id: "150-400", label: "$150 to $400", w: {} },
      { id: "any", label: "Whatever it takes", w: {} }
    ] },
    { id: "time", eyebrow: "Time", question: "How much time per week, really?", options: [
      { id: "u1h", label: "Under 1 hour", w: { grooming: 2, hair: 1 } },
      { id: "1-3h", label: "1 to 3 hours", w: { skin: 1, grooming: 1, style: 1 } },
      { id: "3-5h", label: "3 to 5 hours", w: { physique: 1, style: 1 } },
      { id: "5h+", label: "5 hours or more", w: { physique: 2 } }
    ] },
    { id: "tried", eyebrow: "Before", question: "Ever tried something that didn't work?", options: [
      { id: "products", label: "Products bought at random", w: { skin: 2 } },
      { id: "youtube", label: "Contradicting YouTube advice", w: { face: 1, hair: 1 } },
      { id: "gym", label: "A gym membership I dropped", w: { physique: 2 } },
      { id: "never", label: "Never tried anything", w: { grooming: 1, style: 1 } }
    ] }
  ],
  optionLabel: function (qid, oid) {
    var q = this.questions.filter(function (x) { return x.id === qid; })[0];
    var o = q && q.options.filter(function (x) { return x.id === oid; })[0];
    return o ? o.label : "";
  },
  isComplete: function (answers) {
    return !!answers && this.questions.every(function (q) { return !!answers[q.id]; });
  },
  compute: function (answers) {
    var scores = { face: 0, skin: 0, hair: 0, physique: 0, grooming: 0, style: 0 };
    this.questions.forEach(function (q) {
      var sel = answers[q.id];
      if (!sel) return;
      var opt = q.options.filter(function (o) { return o.id === sel; })[0];
      if (!opt) return;
      Object.keys(opt.w).forEach(function (k) { scores[k] += opt.w[k]; });
    });
    var order = this.categories.map(function (c) { return c.id; });
    var ranked = order.slice().sort(function (a, b) { return scores[b] - scores[a] || order.indexOf(a) - order.indexOf(b); });
    var max = Math.max(1, Math.max.apply(null, ranked.map(function (c) { return scores[c]; })));
    var self = this;
    return ranked.map(function (id, i) {
      var cat = self.categories.filter(function (c) { return c.id === id; })[0];
      var level = i < 2 ? "high" : i < 4 ? "medium" : "low";
      return { id: id, name: cat.name, handle: cat.handle, rank: i + 1, level: level, score: Math.round((scores[id] / max) * 100), why: self.why[id], rankCopy: self.rankCopy[Math.min(i, 2)] };
    });
  },
  profile: function (answers) {
    return { goal: this.optionLabel("focus", answers.focus), commitment: this.optionLabel("time", answers.time), confidence: this.optionLabel("photo", answers.photo), budget: this.optionLabel("budget", answers.budget), tried: this.optionLabel("tried", answers.tried), age: this.optionLabel("age", answers.age) };
  },
  isMinor: function (answers) { return !!answers && answers[this.exitOption.question] === this.exitOption.option; },
  keys: ["aestheticAssessmentAnswers", "aestheticTopPriority", "aestheticSecondPriority", "aestheticThirdPriority", "aestheticGoal", "aestheticCommitment", "aestheticRecommendedProduct", "aestheticAssessmentCompleted", "aestheticAssessmentTimestamp"],
  _get: function (k) { try { return localStorage.getItem(k) || sessionStorage.getItem(k); } catch (e) { return null; } },
  _set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} try { sessionStorage.setItem(k, v); } catch (e) {} },
  _json: function (v) { try { return JSON.parse(v || "null"); } catch (e) { return null; } },
  saveAnswers: function (answers) { this._set("aestheticAssessmentAnswers", JSON.stringify(answers)); },
  persist: function (answers, ranked, product) {
    var pick = function (p) { return p ? { id: p.id, name: p.name, handle: p.handle, level: p.level, score: p.score } : null; };
    var prof = this.profile(answers);
    this._set("aestheticAssessmentAnswers", JSON.stringify(answers));
    this._set("aestheticTopPriority", JSON.stringify(pick(ranked[0])));
    this._set("aestheticSecondPriority", JSON.stringify(pick(ranked[1])));
    this._set("aestheticThirdPriority", JSON.stringify(pick(ranked[2])));
    this._set("aestheticGoal", prof.goal);
    this._set("aestheticCommitment", prof.commitment);
    this._set("aestheticRecommendedProduct", JSON.stringify(product || null));
    this._set("aestheticAssessmentCompleted", "true");
    this._set("aestheticAssessmentTimestamp", new Date().toISOString());
  },
  loadState: function () {
    return {
      answers: this._json(this._get("aestheticAssessmentAnswers")) || {},
      completed: this._get("aestheticAssessmentCompleted") === "true",
      top: this._json(this._get("aestheticTopPriority")),
      second: this._json(this._get("aestheticSecondPriority")),
      third: this._json(this._get("aestheticThirdPriority")),
      goal: this._get("aestheticGoal"),
      commitment: this._get("aestheticCommitment"),
      product: this._json(this._get("aestheticRecommendedProduct")),
      timestamp: this._get("aestheticAssessmentTimestamp")
    };
  },
  clear: function () {
    this.keys.forEach(function (k) { try { localStorage.removeItem(k); } catch (e) {} try { sessionStorage.removeItem(k); } catch (e) {} });
  }
};
