/* Aesthetic Lab assessment icons.
   One line-art icon per answer, keyed "questionId:optionId". Drawn on a 48x48 grid,
   stroke inherits currentColor. Add an entry here and the option renders as an icon card. */
(function () {
  var FACE = '<path d="M14 18c0-7 4-12 10-12s10 5 10 12c0 8-4 15-10 15S14 26 14 18z"/>';
  var BUST = '<path d="M18 32l-1 4c-6 2-9 4-9 8h32c0-4-3-6-9-8l-1-4"/>';
  var CLOCK = '<circle cx="24" cy="24" r="16"/><path d="M24 12v2M36 24h-2M24 36v-2M12 24h2"/>';
  var DUMBBELL = '<path d="M8 20v8M12 16v16M36 16v16M40 20v8M12 24h24"/>';
  var HEART = '<path d="M24 41s-15-9-15-20a8 8 0 0 1 15-4 8 8 0 0 1 15 4c0 11-15 20-15 20z"/>';
  var sector = function (d) { return '<path d="' + d + '" fill="currentColor" fill-opacity=".18"/>'; };

  window.AL_ICONS = {
    /* 01 Focus */
    "focus:overall": FACE + BUST + '<path d="M39 6v6M36 9h6"/>',
    "focus:skin": FACE + '<circle cx="19" cy="22" r="1" fill="currentColor"/><circle cx="22" cy="26" r="1" fill="currentColor"/><circle cx="17" cy="27" r="1" fill="currentColor"/><path d="M38 34c0-2 3-5 3-5s3 3 3 5a3 3 0 0 1-6 0z"/>',
    "focus:hair": FACE + '<path d="M13 19c-1-9 4-14 11-14s12 5 11 14c-2-6-6-8-11-8s-9 2-11 8z"/><path d="M35 19c3 5 3 12-1 18M13 19c-3 5-3 12 1 18M24 5v6"/>',
    "focus:face": FACE + '<path d="M18 17q2.5-2 5 0M25 17q2.5-2 5 0"/><path d="M15 23c1 6 5 9 9 9s8-3 9-9" stroke-dasharray="2 2.6"/>',
    "focus:physique": '<path d="M24 5a4 4 0 1 1 0 8 4 4 0 0 1 0-8z"/><path d="M11 43l2-18-4 6-4-2 6-10c3-2 8-3 13-3s10 1 13 3l6 10-4 2-4-6 2 18z"/>',
    "focus:style": '<path d="M17 8l-9 5 3 7 5-2v22h16V18l5 2 3-7-9-5c-1 3-4 4-7 4s-6-1-7-4z"/>',

    /* 02 Routine */
    "routine:none": '<circle cx="24" cy="24" r="14" stroke-dasharray="3 3.2"/><path d="M18 24h12"/>',
    "routine:basic": '<path d="M20 6h8v6h-8zM18 12h12v28H18z"/><path d="M22 20h4M22 24h4"/><path d="M36 30v10" stroke-dasharray="2 2.6"/>',
    "routine:consistent": '<rect x="8" y="10" width="32" height="30" rx="4"/><path d="M8 18h32M16 6v8M32 6v8M15 28l3 3 6-6M27 28l3 3 6-6"/>',
    "routine:full": '<path d="M9 20h7v20H9zM20 12h8v28h-8zM32 16h7v24h-7z"/><path d="M13 26h1M24 20v6M35 22h1"/><path d="M37 5v5M34.5 7.5h5"/>',

    /* 03 Activity */
    "activity:none": '<path d="M12 22v-8a4 4 0 0 1 4-4h16a4 4 0 0 1 4 4v8"/><path d="M8 25a3 3 0 0 1 6 0v5h20v-5a3 3 0 0 1 6 0v10H8z"/><path d="M12 35v4M36 35v4"/>',
    "activity:light": '<circle cx="28" cy="8" r="3.5"/><path d="M20 43l5-12-5-4 3-9 5 2 3 6 6 2"/><path d="M28 30l5 5 2 8M23 18l-5 3-2 6"/>',
    "activity:regular": DUMBBELL,
    "activity:high": '<path d="M26 3l-7 11h6l-4 10 8-12h-5z"/><path d="M8 30v8M12 27v14M36 27v14M40 30v8M12 34h24"/>',

    /* 04 Confidence */
    "confidence:low": '<circle cx="24" cy="19" r="11"/><path d="M24 30v10M19 40h10"/><path d="M9 6l30 30"/>',
    "confidence:mixed": '<circle cx="16" cy="16" r="6"/><path d="M16 5v3M5 16h3M8 8l2 2M24 8l-2 2"/><path d="M22 40h15a6 6 0 0 0 0-12 8 8 0 0 0-15-2 7 7 0 0 0 0 14z"/>',
    "confidence:good": '<circle cx="21" cy="27" r="12"/><path d="M16 30c2 2 8 2 10 0"/><circle cx="17" cy="24" r="1.2" fill="currentColor"/><circle cx="25" cy="24" r="1.2" fill="currentColor"/><path d="M38 17V6M33 11l5-5 5 5"/>',
    "confidence:high": '<path d="M24 5l5.5 11 12 1.8-8.7 8.5 2 12L24 32.5 13.2 38.3l2-12L6.5 17.8l12-1.8z"/>',

    /* 05 Impression */
    "impression:dating": HEART,
    "impression:career": '<rect x="6" y="15" width="36" height="24" rx="4"/><path d="M17 15v-4a3 3 0 0 1 3-3h8a3 3 0 0 1 3 3v4M6 25h36M22 25v4h4v-4"/>',
    "impression:social": '<circle cx="16" cy="15" r="5"/><circle cx="35" cy="17" r="4"/><path d="M5 38c0-7 5-11 11-11s11 4 11 11M29 38c0-6 2.5-9 6-9s7 3 7 9"/>',
    "impression:photos": '<rect x="5" y="14" width="38" height="26" rx="5"/><path d="M17 14l3-5h8l3 5"/><circle cx="24" cy="27" r="7"/><circle cx="36" cy="20" r="1.2" fill="currentColor"/>',

    /* 06 Habits */
    "habits:poor": '<path d="M30 6a14 14 0 1 0 12 20A12 12 0 0 1 30 6z"/><path d="M8 8l32 32"/>',
    "habits:average": '<path d="M8 34a16 16 0 0 1 32 0"/><path d="M24 34l-6-11"/><circle cx="24" cy="34" r="2.2" fill="currentColor"/><path d="M8 40h32"/>',
    "habits:good": '<path d="M8 40C8 20 20 8 40 8c0 20-12 32-32 32z"/><path d="M8 40L30 18"/>',
    "habits:dialed": '<circle cx="24" cy="24" r="16"/><circle cx="24" cy="24" r="9"/><circle cx="24" cy="24" r="2.5" fill="currentColor"/>',

    /* 07 Commitment */
    "commitment:under-1h": CLOCK + sector("M24 24V10A14 14 0 0 1 31 11.9z"),
    "commitment:1-3h": CLOCK + sector("M24 24V10A14 14 0 0 1 38 24z"),
    "commitment:3-6h": CLOCK + sector("M24 24V10A14 14 0 0 1 24 38z"),
    "commitment:6h+": CLOCK + sector("M24 24V10A14 14 0 1 1 10 24z"),

    /* v2 quiz */
    "focus:jaw": FACE + '<path d="M15 22c2 7 5 11 9 11s7-4 9-11" fill="currentColor" fill-opacity=".18"/><path d="M18 17q2.5-2 5 0M25 17q2.5-2 5 0"/>',
    "focus:all": FACE + BUST + '<path d="M39 6v6M36 9h6"/>',
    "age:u18": '<circle cx="24" cy="24" r="17"/><text x="24" y="28.5" text-anchor="middle" font-family="Inter, system-ui, sans-serif" font-size="14" font-weight="600" fill="currentColor" stroke="none"><18</text>',
    "age:18-24": '<circle cx="24" cy="24" r="17"/><text x="24" y="28.5" text-anchor="middle" font-family="Inter, system-ui, sans-serif" font-size="11" font-weight="600" fill="currentColor" stroke="none">18-24</text>',
    "age:25-34": '<circle cx="24" cy="24" r="17"/><text x="24" y="28.5" text-anchor="middle" font-family="Inter, system-ui, sans-serif" font-size="11" font-weight="600" fill="currentColor" stroke="none">25-34</text>',
    "age:35-44": '<circle cx="24" cy="24" r="17"/><text x="24" y="28.5" text-anchor="middle" font-family="Inter, system-ui, sans-serif" font-size="11" font-weight="600" fill="currentColor" stroke="none">35-44</text>',
    "age:45+": '<circle cx="24" cy="24" r="17"/><text x="24" y="28.5" text-anchor="middle" font-family="Inter, system-ui, sans-serif" font-size="13" font-weight="600" fill="currentColor" stroke="none">45+</text>',
    "routine:soap": '<path d="M14 22h12v14a3 3 0 0 1-3 3h-6a3 3 0 0 1-3-3z"/><path d="M16 22v-3a4 4 0 0 1 8 0v3"/><path d="M36 30c0-2 3-5 3-5s3 3 3 5a3 3 0 0 1-6 0z"/><path d="M31 14c0-2 2-4 2-4s2 2 2 4a2 2 0 0 1-4 0z"/>',
    "haircut:photo": '<rect x="5" y="14" width="38" height="26" rx="5"/><path d="M17 14l3-5h8l3 5"/><circle cx="24" cy="27" r="7"/><circle cx="36" cy="20" r="1.2" fill="currentColor"/>',
    "haircut:words": '<circle cx="16" cy="15" r="5"/><circle cx="35" cy="17" r="4"/><path d="M5 38c0-7 5-11 11-11s11 4 11 11M29 38c0-6 2.5-9 6-9s7 3 7 9"/>',
    "haircut:barber": '<circle cx="15" cy="31" r="5"/><circle cx="15" cy="17" r="5"/><path d="M19 20l20 12M19 28l20-12"/>',
    "haircut:self": '<circle cx="17" cy="33" r="4.5"/><circle cx="17" cy="19" r="4.5"/><path d="M21 22l16 9M21 30l16-9"/><path d="M36 8c-4 0-7 3-7 7s3 7 7 7" stroke-dasharray="2 2.6"/>',
    "training:0": '<path d="M12 22v-8a4 4 0 0 1 4-4h16a4 4 0 0 1 4 4v8"/><path d="M8 25a3 3 0 0 1 6 0v5h20v-5a3 3 0 0 1 6 0v10H8z"/><path d="M12 35v4M36 35v4"/>',
    "training:1-2": '<circle cx="28" cy="8" r="3.5"/><path d="M20 43l5-12-5-4 3-9 5 2 3 6 6 2"/><path d="M28 30l5 5 2 8M23 18l-5 3-2 6"/>',
    "training:3-4": DUMBBELL,
    "training:5+": '<path d="M26 3l-7 11h6l-4 10 8-12h-5z"/><path d="M8 30v8M12 27v14M36 27v14M40 30v8M12 34h24"/>',
    "photo:skin": FACE + '<circle cx="19" cy="22" r="1" fill="currentColor"/><circle cx="22" cy="26" r="1" fill="currentColor"/><circle cx="17" cy="27" r="1" fill="currentColor"/><path d="M38 34c0-2 3-5 3-5s3 3 3 5a3 3 0 0 1-6 0z"/>',
    "photo:jaw": FACE + '<path d="M15 22c2 7 5 11 9 11s7-4 9-11" fill="currentColor" fill-opacity=".18"/><path d="M18 17q2.5-2 5 0M25 17q2.5-2 5 0"/>',
    "photo:hair": FACE + '<path d="M13 19c-1-9 4-14 11-14s12 5 11 14c-2-6-6-8-11-8s-9 2-11 8z"/><path d="M35 19c3 5 3 12-1 18M13 19c-3 5-3 12 1 18M24 5v6"/>',
    "photo:body": '<path d="M24 5a4 4 0 1 1 0 8 4 4 0 0 1 0-8z"/><path d="M11 43l2-18-4 6-4-2 6-10c3-2 8-3 13-3s10 1 13 3l6 10-4 2-4-6 2 18z"/>',
    "photo:avoid": '<circle cx="24" cy="19" r="11"/><path d="M24 30v10M19 40h10"/><path d="M9 6l30 30"/>',
    "budget:u50": '<circle cx="24" cy="24" r="17"/><text x="24" y="28.5" text-anchor="middle" font-family="Inter, system-ui, sans-serif" font-size="12" font-weight="600" fill="currentColor" stroke="none"><$50</text>',
    "budget:50-150": '<circle cx="24" cy="24" r="17"/><text x="24" y="28.5" text-anchor="middle" font-family="Inter, system-ui, sans-serif" font-size="12" font-weight="600" fill="currentColor" stroke="none">$50+</text>',
    "budget:150-400": '<circle cx="24" cy="24" r="17"/><text x="24" y="28.5" text-anchor="middle" font-family="Inter, system-ui, sans-serif" font-size="11" font-weight="600" fill="currentColor" stroke="none">$150+</text>',
    "budget:any": '<circle cx="24" cy="24" r="17"/><path d="M14 24c3-3.5 5-5 7-5s3 2.5 3 5 1 5 3 5 4-1.5 7-5"/>',
    "time:u1h": CLOCK + sector("M24 24V10A14 14 0 0 1 31 11.9z"),
    "time:1-3h": CLOCK + sector("M24 24V10A14 14 0 0 1 38 24z"),
    "time:3-5h": CLOCK + sector("M24 24V10A14 14 0 0 1 24 38z"),
    "time:5h+": CLOCK + sector("M24 24V10A14 14 0 1 1 10 24z"),
    "tried:products": '<path d="M20 6h8v6h-8zM18 12h12v28H18z"/><path d="M22 20h4M22 24h4"/><path d="M8 8l32 32"/>',
    "tried:youtube": '<rect x="5" y="11" width="38" height="26" rx="7"/><path d="M20 17l11 7-11 7z" fill="currentColor"/>',
    "tried:gym": '<path d="M8 20v8M12 16v16M36 16v16M40 20v8M12 24h24"/><path d="M8 8l32 32"/>',
    "tried:never": '<circle cx="24" cy="24" r="14" stroke-dasharray="3 3.2"/><path d="M18 24h12"/>',

    /* 08 Goal */
    "goal:healthier": HEART + '<path d="M11 22h7l3-5 4 10 3-5h9"/>',
    "goal:sharper": '<path d="M14 8h20l8 10-18 24L6 18zM6 18h36M18 18l6 24M30 18l-6 24"/>',
    "goal:masculine": FACE + '<path d="M15 22c2 7 5 11 9 11s7-4 9-11" fill="currentColor" fill-opacity=".18"/><path d="M18 17q2.5-2 5 0M25 17q2.5-2 5 0"/>',
    "goal:refined": '<path d="M6 16l14 8-14 8zM42 16l-14 8 14 8z"/><rect x="20" y="20" width="8" height="8" rx="2"/>',
    "goal:confidence": '<path d="M24 5l16 5v12c0 10-7 17-16 21-9-4-16-11-16-21V10z"/><path d="M17 24l5 5 9-10"/>',
    "goal:presentation": '<rect x="8" y="6" width="32" height="36" rx="4"/><circle cx="24" cy="19" r="5"/><path d="M15 36c1-6 4-9 9-9s8 3 9 9"/>'
  };

  var CHECK = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3.5 8.5l3 3 6-7"/></svg>';

  /* Builds an answer card. Falls back to null when no icon exists for this option. */
  window.AL_OPTION_CARD = function (q, o, i, on, attr) {
    var ic = window.AL_ICONS[q.id + ":" + o.id];
    if (!ic) return null;
    return '<button type="button" class="opt-card" ' + attr + '="' + o.id + '"' + (on ? " data-on" : "") + ' style="animation-delay:' + i * 45 + 'ms">' +
      '<span class="opt-card__check">' + CHECK + "</span>" +
      '<span class="opt-card__icon"><svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ic + "</svg></span>" +
      '<span class="opt-card__label">' + o.label + "</span></button>";
  };
})();
