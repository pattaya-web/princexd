/* Aesthetic Lab theme JS: header capsule, menus, cart drawer (Ajax API), GSAP reveals,
   tabs, before/after sliders, sticky product CTA, quick check, assessment, results. */
(function () {
  "use strict";
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var money = function (cents) {
    var fmt = window.AL_MONEY_FORMAT || "${{amount}}";
    var group = function (n, sep) { return n.replace(/\B(?=(\d{3})+(?!\d))/g, sep); };
    return fmt.replace(/\{\{\s*(\w+)\s*\}\}/, function (_, key) {
      var v = cents / 100, whole = Math.round(v).toString(), fixed = v.toFixed(2);
      switch (key) {
        case "amount_no_decimals": return group(whole, ",");
        case "amount_with_comma_separator": return group(fixed.split(".")[0], ".") + "," + fixed.split(".")[1];
        case "amount_no_decimals_with_comma_separator": return group(whole, ".");
        case "amount_with_space_separator": return group(fixed.split(".")[0], " ") + "," + fixed.split(".")[1];
        case "amount_no_decimals_with_space_separator": return group(whole, " ");
        case "amount_with_apostrophe_separator": return group(fixed.split(".")[0], "'") + "." + fixed.split(".")[1];
        default: return group(fixed.split(".")[0], ",") + "." + fixed.split(".")[1];
      }
    });
  };

  /* Header */
  var header = document.querySelector("[data-header]");
  if (header) {
    var lightAtTop = header.hasAttribute("data-light-at-top");
    var update = function () {
      var scrolled = window.scrollY > 40;
      header.classList.toggle("site-header--capsule", scrolled);
      header.classList.toggle("site-header--light", !scrolled && lightAtTop);
    };
    update();
    window.addEventListener("scroll", update, { passive: true });
  }
  var menu = document.querySelector("[data-mobile-menu]");
  document.querySelectorAll("[data-menu-open]").forEach(function (b) {
    b.addEventListener("click", function () { menu.setAttribute("data-open", "true"); document.body.style.overflow = "hidden"; });
  });
  document.querySelectorAll("[data-menu-close]").forEach(function (b) {
    b.addEventListener("click", function () { menu.setAttribute("data-open", "false"); document.body.style.overflow = ""; });
  });

  /* Cart drawer */
  var drawer = document.querySelector("[data-cart-drawer]");
  function openDrawer() { if (!drawer) return; drawer.setAttribute("data-open", "true"); document.body.style.overflow = "hidden"; }
  function closeDrawer() { if (!drawer) return; drawer.setAttribute("data-open", "false"); document.body.style.overflow = ""; }
  function renderCart(cart) {
    if (!drawer) return;
    var body = drawer.querySelector("[data-cart-lines]");
    var foot = drawer.querySelector("[data-cart-foot]");
    var empty = drawer.querySelector("[data-cart-empty]");
    document.querySelectorAll("[data-cart-count]").forEach(function (el) { el.textContent = cart.item_count; el.setAttribute("data-count", cart.item_count); });
    var upWrap = drawer.querySelector("[data-cart-upsell-wrap]");
    if (upWrap) {
      var inBag = cart.items.map(function (it) { return String(it.product_id); }), visible = 0;
      upWrap.querySelectorAll("[data-cart-upsell-row]").forEach(function (row) { var hide = inBag.indexOf(row.getAttribute("data-product-id")) >= 0; row.hidden = hide; if (!hide) visible++; });
      upWrap.hidden = !cart.items.length || visible === 0;
    }
    if (!cart.items.length) { body.innerHTML = ""; empty.hidden = false; foot.hidden = true; return; }
    empty.hidden = true; foot.hidden = false;
    body.innerHTML = cart.items.map(function (it) {
      return '<div class="cart-line card">' +
        '<div class="cart-line__media media media--4x5">' + (it.image ? '<img src="' + it.image.replace(/(\.[a-z]+)(\?|$)/, "_160x$1$2") + '" alt="">' : "") + "</div>" +
        '<div class="cart-line__body"><span class="eyebrow">' + (it.product_type || "Digital") + '</span>' +
        '<a href="' + it.url + '" class="small" style="margin-top:.25rem;font-weight:500">' + it.product_title + "</a>" +
        '<div class="cart-line__row"><span class="tnum">' + money(it.final_line_price) + '</span>' +
        '<button type="button" class="cart-line__remove" data-remove="' + it.key + '">Remove</button></div></div></div>';
    }).join("");
    drawer.querySelector("[data-cart-subtotal]").textContent = money(cart.items_subtotal_price);
    body.querySelectorAll("[data-remove]").forEach(function (b) {
      b.addEventListener("click", function () {
        fetch("/cart/change.js", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: b.getAttribute("data-remove"), quantity: 0 }) })
          .then(function (r) { return r.json(); }).then(renderCart);
      });
    });
  }
  function refreshCart() { return fetch("/cart.js").then(function (r) { return r.json(); }).then(renderCart); }
  window.AL_CART = { refresh: refreshCart, open: openDrawer };
  document.querySelectorAll("[data-cart-open]").forEach(function (b) { b.addEventListener("click", function () { refreshCart().then(openDrawer); }); });
  document.querySelectorAll("[data-cart-close]").forEach(function (b) { b.addEventListener("click", closeDrawer); });
  document.addEventListener("submit", function (e) {
    var form = e.target;
    if (!form.matches("[data-add-to-cart]") && form.getAttribute("data-cart-mode") !== "ajax") return;
    e.preventDefault();
    var btn = form.querySelector("[type=submit]");
    if (btn) btn.disabled = true;
    var qty = Math.max(1, parseInt((form.querySelector("[name=quantity]") || {}).value, 10) || 1);
    var bundleIds = form.getAttribute("data-bundle");
    var props = {}; try { new FormData(form).forEach(function (v, k) { var m = /^properties\[(.+)\]$/.exec(k); if (m && v !== "") props[m[1]] = v; }); } catch (err) {}
    var withProps = function (it) { if (Object.keys(props).length) it.properties = props; return it; };
    var items = bundleIds ? bundleIds.split(",").map(function (id) { return withProps({ id: parseInt(id, 10), quantity: qty }); }) : [withProps({ id: form.querySelector("[name=id]").value, quantity: qty })];
    fetch("/cart/add.js", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ items: items }) })
      .then(function (r) { return r.json(); })
      .then(function () { return refreshCart(); })
      .then(openDrawer)
      .finally(function () { if (btn) btn.disabled = false; });
  });
  document.addEventListener("keydown", function (e) {
    if (e.key !== "Escape") return;
    closeDrawer();
    if (menu) { menu.setAttribute("data-open", "false"); document.body.style.overflow = ""; }
    document.querySelectorAll("[data-quickcheck]").forEach(function (m) { m.setAttribute("data-open", "false"); });
  });
  refreshCart();

  /* GSAP motion */
  var hasGsap = window.gsap && window.ScrollTrigger;
  if (hasGsap) gsap.registerPlugin(ScrollTrigger);
  function splitWords(el) {
    var parts = [];
    el.childNodes.forEach(function (node) {
      if (node.nodeType === 3) {
        node.textContent.split(" ").filter(Boolean).forEach(function (w) { parts.push({ text: w, cls: "" }); });
      } else if (node.nodeType === 1) {
        var cls = node.className || "";
        if (node.tagName === "BR") { parts.push({ br: true }); return; }
        node.textContent.split(" ").filter(Boolean).forEach(function (w) { parts.push({ text: w, cls: cls }); });
      }
    });
    el.innerHTML = parts.map(function (p) {
      if (p.br) return "<br>";
      return '<span class="reveal-word-wrap"><span class="reveal-word ' + p.cls + '">' + p.text + "&nbsp;</span></span>";
    }).join("");
  }
  document.querySelectorAll("[data-text-reveal]").forEach(function (el) {
    splitWords(el);
    var words = el.querySelectorAll(".reveal-word");
    if (!hasGsap || reduce) { words.forEach(function (w) { w.style.opacity = 1; }); return; }
    gsap.fromTo(words, { autoAlpha: 0, y: "0.6em" }, { autoAlpha: 1, y: 0, duration: 0.9, ease: "power3.out", stagger: 0.045, scrollTrigger: { trigger: el, start: el.closest(".hero") ? "top 100%" : "top 90%", once: true } });
  });
  document.querySelectorAll("[data-reveal]").forEach(function (el) {
    var stagger = el.getAttribute("data-reveal-stagger");
    var targets = stagger ? Array.prototype.slice.call(el.children) : [el];
    if (stagger) { el.classList.remove("reveal"); targets.forEach(function (t) { t.classList.add("reveal"); }); } else el.classList.add("reveal");
    if (!hasGsap || reduce) { targets.forEach(function (t) { t.style.opacity = 1; }); return; }
    gsap.fromTo(targets, { autoAlpha: 0, y: 28 }, { autoAlpha: 1, y: 0, duration: 1.1, ease: "power3.out", stagger: stagger ? parseFloat(stagger) : 0, delay: parseFloat(el.getAttribute("data-reveal-delay") || 0) / 1000, scrollTrigger: { trigger: el, start: el.closest(".hero") ? "top 100%" : "top 88%", once: true } });
  });
  document.querySelectorAll("[data-parallax]").forEach(function (el) {
    if (!hasGsap || reduce) return;
    var amt = parseFloat(el.getAttribute("data-parallax") || 40);
    gsap.fromTo(el, { y: -amt / 2 }, { y: amt / 2, ease: "none", scrollTrigger: { trigger: el, start: "top bottom", end: "bottom top", scrub: 0.6 } });
  });
  document.querySelectorAll("[data-countup]").forEach(function (el) {
    var value = parseFloat(el.getAttribute("data-countup")), suffix = el.getAttribute("data-suffix") || "";
    if (!hasGsap || reduce) { el.textContent = value + suffix; return; }
    var c = { n: 0 };
    gsap.to(c, { n: value, duration: 1.4, ease: "power2.out", scrollTrigger: { trigger: el, start: "top 90%", once: true }, onUpdate: function () { el.textContent = Math.round(c.n) + suffix; } });
  });

  /* Tabs */
  window.AL_SCOPE_INITS = window.AL_SCOPE_INITS || [];
  var initTabs = function (scope) { (scope || document).querySelectorAll("[data-tabs]").forEach(function (root) {
    if (root.getAttribute("data-init-tabs")) return; root.setAttribute("data-init-tabs", "1");
    var btns = root.querySelectorAll("[role=tab]"), panels = root.querySelectorAll("[role=tabpanel]");
    btns.forEach(function (b, i) {
      b.addEventListener("click", function () {
        btns.forEach(function (x, j) { x.setAttribute("aria-selected", i === j); });
        panels.forEach(function (p, j) { p.hidden = i !== j; if (i === j) { p.classList.remove("step-in"); void p.offsetWidth; p.classList.add("step-in"); } });
      });
    });
  }); };
  initTabs(document); window.AL_SCOPE_INITS.push(initTabs);

  /* Before / after */
  var initBa = function (scope) { (scope || document).querySelectorAll("[data-ba]").forEach(function (root) {
    if (root.getAttribute("data-init-ba")) return; root.setAttribute("data-init-ba", "1");
    var after = root.querySelector(".ba__after"), line = root.querySelector(".ba__line"), range = root.querySelector(".ba__range");
    var set = function (p) { p = Math.min(96, Math.max(4, p)); after.style.clipPath = "inset(0 0 0 " + p + "%)"; line.style.left = p + "%"; range.value = Math.round(p); };
    set(reduce ? 50 : 8);
    if (hasGsap && !reduce) { var s = { p: 8 }; gsap.to(s, { p: 50, duration: 1.6, ease: "power3.inOut", scrollTrigger: { trigger: root, start: "top 80%", once: true }, onUpdate: function () { set(s.p); } }); }
    var drag = function (e) { if (e.buttons !== 1 && e.type !== "pointerdown") return; var r = root.getBoundingClientRect(); set(((e.clientX - r.left) / r.width) * 100); };
    root.addEventListener("pointerdown", drag); root.addEventListener("pointermove", drag);
    range.addEventListener("input", function () { set(Number(range.value)); });
  }); };
  initBa(document); window.AL_SCOPE_INITS.push(initBa);

  /* Product gallery */
  window.AL_INIT_SCOPE = function (scope) { (window.AL_SCOPE_INITS || []).forEach(function (f) { try { f(scope); } catch (e) {} }); };
  var initGallery = function (scope) { (scope || document).querySelectorAll("[data-gallery]").forEach(function (root) {
    if (root.getAttribute("data-init")) return; root.setAttribute("data-init", "1");
    var thumbs = root.querySelectorAll("[data-gallery-thumb]"), slides = root.querySelectorAll("[data-gallery-slide]");
    var cur = 0; slides.forEach(function (s, j) { if (!s.hidden) cur = j; });
    var go = function (i, dir) {
      if (!slides.length) return; i = (i + slides.length) % slides.length; if (i === cur && dir) return;
      thumbs.forEach(function (x, j) { x.setAttribute("aria-selected", i === j); if (i === j && x.scrollIntoView) x.scrollIntoView({ block: "nearest", inline: "nearest" }); });
      slides.forEach(function (s, j) { s.hidden = i !== j; if (i === j && dir) { s.classList.remove("slide-in-left", "slide-in-right"); void s.offsetWidth; s.classList.add(dir > 0 ? "slide-in-right" : "slide-in-left"); } });
      cur = i; window.ScrollTrigger && ScrollTrigger.refresh();
    };
    thumbs.forEach(function (t, i) { t.addEventListener("click", function () { go(i, i > cur ? 1 : i < cur ? -1 : 0); }); });
    /* Swipe on the main image to move between slides */
    var main = root.querySelector(".gallery__main"), sx = null, sy = null, axis = null;
    if (main && slides.length > 1) {
      main.addEventListener("touchstart", function (e) { sx = e.touches[0].clientX; sy = e.touches[0].clientY; axis = null; }, { passive: true });
      main.addEventListener("touchmove", function (e) { if (sx === null || axis) return; var dx = e.touches[0].clientX - sx, dy = e.touches[0].clientY - sy; if (Math.abs(dx) > 8 || Math.abs(dy) > 8) axis = Math.abs(dx) > Math.abs(dy) ? "x" : "y"; }, { passive: true });
      main.addEventListener("touchend", function (e) { if (sx === null) return; var dx = e.changedTouches[0].clientX - sx; if (axis === "x" && Math.abs(dx) > 40) go(cur + (dx < 0 ? 1 : -1), dx < 0 ? 1 : -1); sx = sy = null; axis = null; });
    }
  }); };
  initGallery(document); window.AL_SCOPE_INITS.push(initGallery);

  /* Sticky product CTA */
  var sticky = document.querySelector("[data-sticky-cta]");
  var watch = document.getElementById("primary-cta");
  if (sticky && watch && "IntersectionObserver" in window) {
    new IntersectionObserver(function (entries) { var e = entries[0]; sticky.setAttribute("data-visible", !e.isIntersecting && e.boundingClientRect.top < 0); }).observe(watch);
  }

  /* Fit a heading on one line by shrinking its font size */
  var fitOne = function () {
    document.querySelectorAll("[data-fit]").forEach(function (el) {
      el.style.fontSize = "";
      var size = parseFloat(getComputedStyle(el).fontSize), min = parseFloat(el.getAttribute("data-fit-min") || 18), guard = 40;
      while (el.scrollWidth > el.clientWidth + 1 && size > min && guard--) { size -= 1; el.style.fontSize = size + "px"; }
    });
  };
  fitOne(); window.addEventListener("resize", fitOne);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(fitOne);

  /* Reviews carousel: cards sized from "reviews visible", inset aligned with the heading, thin progress bar */
  var initReviews = function (root) {
    if (root.getAttribute("data-rv-init")) return; root.setAttribute("data-rv-init", "1");
    var track = root.querySelector("[data-reviews-track]"); if (!track) return;
    var heading = root.querySelector(".reviews__heading"), list = track.firstElementChild;
    var bar = root.querySelector("[data-reviews-bar]"), fill = root.querySelector("[data-reviews-bar-fill]");
    var per = function () {
      var w = window.innerWidth;
      return parseFloat(root.getAttribute(w >= 1024 ? "data-per-desktop" : w >= 640 ? "data-per-tablet" : "data-per-mobile")) || 1.25;
    };
    var layout = function () {
      if (!heading || !list) return;
      var inset = Math.max(0, Math.round(heading.getBoundingClientRect().left - track.getBoundingClientRect().left));
      var gap = parseFloat(getComputedStyle(list).gap) || 12;
      var n = per(), visible = track.clientWidth - inset * 2;
      var card = Math.floor((visible - gap * Math.ceil(n - 1)) / n);
      list.style.paddingLeft = inset + "px"; list.style.paddingRight = inset + "px";
      track.style.scrollPaddingLeft = inset + "px"; track.style.scrollPaddingRight = inset + "px";
      root.style.setProperty("--rv-card", Math.max(160, card) + "px");
      progress();
    };
    var progress = function () {
      if (!bar || !fill) return;
      var max = track.scrollWidth - track.clientWidth;
      var ratio = Math.min(1, track.clientWidth / track.scrollWidth);
      fill.style.width = (ratio * 100) + "%";
      var bw = bar.clientWidth, fw = bw * ratio;
      fill.style.transform = "translateX(" + (max > 0 ? (track.scrollLeft / max) * (bw - fw) : 0) + "px)";
    };
    if (bar) bar.addEventListener("click", function (e) {
      var r = bar.getBoundingClientRect(), max = track.scrollWidth - track.clientWidth;
      track.scrollTo({ left: ((e.clientX - r.left) / r.width) * max, behavior: "smooth" });
    });
    /* Desktop arrows: move by one card, disabled at each end. */
    var prev = root.querySelector("[data-reviews-prev]"), next = root.querySelector("[data-reviews-next]");
    var step = function () { var c = list && list.firstElementChild; var gap = parseFloat(getComputedStyle(list).gap) || 12; return c ? c.getBoundingClientRect().width + gap : track.clientWidth * 0.8; };
    var arrows = function () {
      if (!prev || !next) return;
      var max = track.scrollWidth - track.clientWidth - 1;
      prev.disabled = track.scrollLeft <= 1; next.disabled = track.scrollLeft >= max;
    };
    if (prev) prev.addEventListener("click", function () { track.scrollBy({ left: -step(), behavior: "smooth" }); });
    if (next) next.addEventListener("click", function () { track.scrollBy({ left: step(), behavior: "smooth" }); });
    /* Mouse drag to scroll (touch already scrolls natively). */
    var drag = null;
    track.addEventListener("pointerdown", function (e) {
      if (e.pointerType !== "mouse" || e.button !== 0) return;
      drag = { x: e.clientX, left: track.scrollLeft, moved: false };
    });
    window.addEventListener("pointermove", function (e) {
      if (!drag) return;
      var dx = e.clientX - drag.x;
      if (!drag.moved && Math.abs(dx) < 4) return;
      drag.moved = true; track.classList.add("is-dragging"); track.scrollLeft = drag.left - dx;
    });
    var endDrag = function (e) {
      if (!drag) return;
      var moved = drag.moved; drag = null;
      if (moved) { var block = function (ev) { ev.stopPropagation(); ev.preventDefault(); }; track.addEventListener("click", block, { capture: true, once: true }); setTimeout(function () { track.removeEventListener("click", block, { capture: true }); }, 0); }
      setTimeout(function () { track.classList.remove("is-dragging"); }, 50);
    };
    window.addEventListener("pointerup", endDrag); window.addEventListener("pointercancel", endDrag);
    track.addEventListener("scroll", function () { progress(); arrows(); }, { passive: true });
    layout(); arrows(); window.addEventListener("resize", function () { layout(); arrows(); });
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(layout);
    setTimeout(layout, 300);
  };
  document.querySelectorAll("[data-reviews]").forEach(initReviews);
  window.AL_SCOPE_INITS.push(function (scope) { (scope || document).querySelectorAll("[data-reviews]").forEach(initReviews); });
  /* Theme editor re-renders a section after each setting change: re-run the layout on the new DOM. */
  document.addEventListener("shopify:section:load", function (e) { (e.target || document).querySelectorAll("[data-reviews]").forEach(initReviews); });
  document.addEventListener("shopify:block:select", function (e) { var r = e.target && e.target.closest && e.target.closest("[data-reviews]"); if (r) { var t = r.querySelector("[data-reviews-track]"), c = e.target.closest(".review"); if (t && c) t.scrollTo({ left: c.offsetLeft - parseFloat(t.style.scrollPaddingLeft || 0), behavior: "smooth" }); } });

  /* Shared analysis runner: organic 0→100% with rAF, steps, checkmark, then callback. */
  var runAnalysis = function (root, onDone) {
    var pctEl = root.querySelector("[data-ai-pct]"), bar = root.querySelector("[data-ai-bar]"), track = root.querySelector("[data-ai-track]");
    /* Review notes: pop in one after another while the analysis runs. */
    var notes = root.querySelectorAll("[data-ai-note]");
    notes.forEach(function (n) { n.classList.remove("is-in"); });
    notes.forEach(function (n, i) { setTimeout(function () { n.classList.add("is-in"); }, 500 + i * 1100); });
    var steps = Array.prototype.slice.call(root.querySelectorAll("[data-ai-step]"));
    var segs = [[17, 620], [33, 700], [51, 820], [68, 820], [81, 720], [93, 720], [99, 640]];
    var set = function (v) { var r = Math.round(v); pctEl.textContent = r + "%"; bar.style.width = v + "%"; track.setAttribute("aria-valuenow", r); };
    var setSteps = function (active) {
      var per = steps.length / segs.length;
      steps.forEach(function (li, i) {
        var a = Math.min(steps.length, Math.floor(active * per));
        if (active >= segs.length) a = steps.length;
        li.setAttribute("data-state", i < a ? "done" : i === a ? "active" : "");
        if (i < a - 2) li.setAttribute("data-old", ""); else li.removeAttribute("data-old");
      });
    };
    var ease = function (t) { return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2; };
    var tween = function (from, to, ms, cb) {
      var t0 = null;
      var f = function (now) { if (t0 === null) t0 = now; var t = Math.min(1, (now - t0) / ms); set(from + (to - from) * ease(t)); if (t < 1) requestAnimationFrame(f); else cb(); };
      requestAnimationFrame(f);
    };
    var done = function () {
      setSteps(segs.length);
      var doneEl = root.querySelector("[data-ai-done]");
      setTimeout(function () {
        ["[data-ai-copy]", "[data-ai-steps]", "[data-ai-meter]"].forEach(function (s) { root.querySelector(s).classList.add("is-out"); });
        setTimeout(function () {
          doneEl.hidden = false; void doneEl.offsetWidth; doneEl.classList.add("is-on");
          setTimeout(onDone, 700 + 900);
        }, 380);
      }, 200);
    };
    var run = function (i, from) {
      if (i >= segs.length) { setTimeout(function () { tween(99, 100, 220, done); }, 380); return; }
      setSteps(i);
      tween(from, segs[i][0], reduce ? 80 : segs[i][1], function () { run(i + 1, segs[i][0]); });
    };
    set(0); setTimeout(function () { run(0, 0); }, 250);
  };

  /* Assessment pop-up: intro → questions → analysis inside the modal, then the results page. */
  document.querySelectorAll("[data-quickcheck]").forEach(function (root) {
    var A = window.AL_ASSESSMENT; if (!A) return;
    var delay = parseInt(root.getAttribute("data-delay") || "1000", 10);
    var phases = {}; root.querySelectorAll("[data-qc-phase]").forEach(function (p) { phases[p.getAttribute("data-qc-phase")] = p; });
    var show = function (name) { Object.keys(phases).forEach(function (k) { phases[k].hidden = k !== name; }); root.setAttribute("data-qc-state", name); };
    var open = function () { root.setAttribute("data-open", "true"); root.setAttribute("aria-hidden", "false"); };
    var close = function () { root.setAttribute("data-open", "false"); root.setAttribute("aria-hidden", "true"); };
    root.querySelectorAll("[data-qc-close]").forEach(function (b) { b.addEventListener("click", close); });
    var assessUrl = root.getAttribute("data-assessment-url");
    document.querySelectorAll("[data-qc-open], a[href='" + assessUrl + "']").forEach(function (b) { b.addEventListener("click", function (e) { e.preventDefault(); open(); }); });
    var pageMode = root.getAttribute("data-mode") === "page";
    if (pageMode) { open(); root.classList.add("is-page"); }
    else {
      var done = false; try { done = localStorage.getItem("aestheticAssessmentCompleted") === "true"; } catch (e) {}
      try { if (!done && !sessionStorage.getItem("al:qc:seen")) setTimeout(function () { sessionStorage.setItem("al:qc:seen", "1"); open(); }, delay); } catch (e) {}
    }

    var answers = {}, step = 0, total = A.questions.length, running = false;
    var pad = function (n) { return String(n).padStart(2, "0"); };
    var product = { handle: root.getAttribute("data-product-handle") || "", title: root.getAttribute("data-product-title") || "", url: root.getAttribute("data-product-url") || "", variant: root.getAttribute("data-product-variant") || "", price: root.getAttribute("data-product-price") || "" };
    var progress = root.querySelector("[data-qc-progress]");
    var renderQ = function () {
      var q = A.questions[step];
      root.querySelector("[data-qc-count]").textContent = "Question " + pad(step + 1) + " / " + pad(total);
      root.querySelector("[data-qc-q]").textContent = q.question;
      root.querySelector("[data-qc-back]").style.visibility = step === 0 ? "hidden" : "visible";
      if (progress) progress.style.width = (step / total) * 100 + "%";
      var opts = root.querySelector("[data-qc-opts]");
      opts.removeAttribute("data-lock");
      opts.innerHTML = q.options.map(function (o, i) {
        var card = window.AL_OPTION_CARD && window.AL_OPTION_CARD(q, o, i, answers[q.id] === o.id, "data-opt");
        return card || '<button type="button" class="qc__opt" data-opt="' + o.id + '"' + (answers[q.id] === o.id ? " data-on" : "") + '><span class="eyebrow">' + String.fromCharCode(65 + i) + "</span><span>" + o.label + "</span></button>";
      }).join("");
      if (opts.querySelector(".opt-card")) opts.setAttribute("data-cards", q.options.length); else opts.removeAttribute("data-cards");
      opts.classList.remove("step-in"); void opts.offsetWidth; opts.classList.add("step-in");
      opts.querySelectorAll("[data-opt]").forEach(function (b) {
        b.addEventListener("click", function () {
          if (opts.getAttribute("data-lock")) return; opts.setAttribute("data-lock", "1");
          answers[q.id] = b.getAttribute("data-opt"); A.saveAnswers(answers);
          opts.querySelectorAll("[data-opt]").forEach(function (x) { if (x === b) x.setAttribute("data-on", ""); else x.removeAttribute("data-on"); });
          if (A.isMinor && A.isMinor(answers)) { setTimeout(function () { show("exit"); }, 240); return; }
          if (step < total - 1) setTimeout(function () { step++; renderQ(); }, 240);
          else setTimeout(toScan, 320);
        });
      });
    };
    var scanApi = null;
    var toScan = function () {
      var box = root.querySelector("[data-qc-scan]");
      if (!box || !window.AL_FACE_SCAN) { finish(); return; }
      if (progress) progress.style.width = "92%";
      show("scan");
      if (!scanApi) scanApi = window.AL_FACE_SCAN.mount(box, { onDone: finish, onSkip: finish });
    };
    var finish = function () {
      if (running || !A.isComplete(answers)) return;
      running = true;
      var ranked = A.compute(answers);
      A.persist(answers, ranked, product.handle ? product : null);
      if (progress) progress.style.width = "100%";
      show("analysis");
      runAnalysis(phases.analysis, function () { window.location.href = root.getAttribute("data-results-url"); });
    };
    root.querySelector("[data-qc-start]").addEventListener("click", function () { answers = {}; step = 0; show("quiz"); renderQ(); });
    root.querySelectorAll("[data-qc-back]").forEach(function (bb) { bb.addEventListener("click", function () { if (root.getAttribute("data-qc-state") === "scan") { if (scanApi) scanApi.destroy(); show("quiz"); renderQ(); return; } if (step > 0) { step--; renderQ(); } }); });
  });

  /* Assessment app: quiz → analysis → results → protocol */
  var assess = document.querySelector("[data-assessment]");
  if (assess && window.AL_ASSESSMENT) {
    var A = window.AL_ASSESSMENT, mode = assess.getAttribute("data-mode") || "full";
    var phases = {}; assess.querySelectorAll("[data-phase]").forEach(function (p) { phases[p.getAttribute("data-phase")] = p; });
    var product = { handle: assess.getAttribute("data-product-handle") || "", title: assess.getAttribute("data-product-title") || "", url: assess.getAttribute("data-product-url") || "", variant: assess.getAttribute("data-product-variant") || "", price: assess.getAttribute("data-product-price") || "" };
    var state = A.loadState(), answers = state.answers || {}, total = A.questions.length, step = 0;
    var pad = function (n) { return String(n).padStart(2, "0"); };
    var scrollTop = function () { window.scrollTo({ top: Math.max(0, assess.getBoundingClientRect().top + window.scrollY - 24), behavior: reduce ? "auto" : "smooth" }); };

    /* Smooth phase swap: out (opacity 1→0, y 0→-16) then in (opacity 0→1, y 26→0). */
    var swap = function (from, to, cb) {
      var finish = function () {
        from.hidden = true; from.classList.remove("is-leaving");
        to.classList.add("is-entering"); to.hidden = false; void to.offsetWidth; to.classList.remove("is-entering");
        scrollTop(); if (cb) cb();
      };
      if (reduce) return finish();
      from.classList.add("is-leaving"); setTimeout(finish, 460);
    };

    /* Quiz */
    var renderQuiz = function () {
      var q = A.questions[step];
      assess.querySelector("[data-a-num]").textContent = pad(step + 1);
      assess.querySelector("[data-a-total]").textContent = " / " + pad(total);
      assess.querySelector("[data-a-bar]").style.width = ((step + 1) / total) * 100 + "%";
      assess.querySelector("[data-a-count]").textContent = "Question " + pad(step + 1) + " / " + pad(total);
      assess.querySelector("[data-a-q]").textContent = q.question;
      assess.querySelector("[data-a-steps]").innerHTML = A.questions.map(function (x, i) {
        return '<li><button type="button" data-go="' + i + '"' + (answers[x.id] ? " data-done" : "") + (i === step ? ' aria-current="step"' : "") + (!answers[x.id] && i > step ? " disabled" : "") + '><span><span class="eyebrow">' + pad(i + 1) + "</span> &nbsp;" + x.eyebrow + "</span></button></li>";
      }).join("");
      assess.querySelector("[data-a-opts]").removeAttribute("data-lock");
      var optBox = assess.querySelector("[data-a-opts]");
      optBox.innerHTML = q.options.map(function (o, i) {
        var card = window.AL_OPTION_CARD && window.AL_OPTION_CARD(q, o, i, answers[q.id] === o.id, "data-pick");
        return card || '<button type="button" class="assess__opt" data-pick="' + o.id + '"' + (answers[q.id] === o.id ? " data-on" : "") + '><span class="eyebrow">' + String.fromCharCode(65 + i) + "</span><span>" + o.label + "</span></button>";
      }).join("");
      if (optBox.querySelector(".opt-card")) optBox.setAttribute("data-cards", q.options.length); else optBox.removeAttribute("data-cards");
      var main = assess.querySelector("[data-a-main]"); main.classList.remove("step-in"); void main.offsetWidth; main.classList.add("step-in");
      var back = assess.querySelector("[data-a-back]"), next = assess.querySelector("[data-a-next]"), finish = assess.querySelector("[data-a-finish]");
      back.style.visibility = step === 0 ? "hidden" : "visible";
      next.hidden = step === total - 1; finish.hidden = step !== total - 1;
      next.disabled = !answers[q.id]; finish.disabled = !A.isComplete(answers);
      assess.querySelectorAll("[data-pick]").forEach(function (b) {
        b.addEventListener("click", function () {
          var box = assess.querySelector("[data-a-opts]"); if (box.getAttribute("data-lock")) return; box.setAttribute("data-lock", "1");
          answers[q.id] = b.getAttribute("data-pick"); A.saveAnswers(answers);
          assess.querySelectorAll("[data-pick]").forEach(function (x) { if (x === b) x.setAttribute("data-on", ""); else x.removeAttribute("data-on"); });
          if (step < total - 1) setTimeout(function () { step++; renderQuiz(); }, 260);
          else setTimeout(goAfterQuiz, 380);
        });
      });
      assess.querySelectorAll("[data-go]").forEach(function (b) { b.addEventListener("click", function () { step = parseInt(b.getAttribute("data-go"), 10); renderQuiz(); }); });
      back.onclick = function () { step = Math.max(0, step - 1); renderQuiz(); };
      next.onclick = function () { step = Math.min(total - 1, step + 1); renderQuiz(); };
      finish.onclick = goAfterQuiz;
    };

    var goAfterQuiz = function () {
      if (!A.isComplete(answers)) return;
      if (phases.photos) { swap(phases.quiz, phases.photos, initPhotos); } else startAnalysis(phases.quiz);
    };
    /* Day-0 face scan: one continuous step, like a phone face setup. Face tracking runs on the device (MediaPipe via CDN).
       Front, left and right photos are taken automatically when each pose is held; then the analysis starts.
       Manual capture and upload remain as fallback when tracking is unavailable. */
    var photosPhase = phases.photos;
    var initPhotos = function () {
      var slots = [
        { id: "front", title: "Look straight at the camera", hint: "Hold still. The first photo is taken automatically.", pose: "front" },
        { id: "left", title: "Slowly turn your head to the left", hint: "Keep turning until the ring fills.", pose: "left" },
        { id: "right", title: "Now turn to the right", hint: "Same on the other side. Hold the pose for a second.", pose: "right" }
      ];
      var idx = 0, shots = {}, stream = null, pending = null, tracker = null, trackerFailed = false, loop = null, hold = 0, lastTs = 0, capturing = false, attempts = 0;
      var q = function (sel) { return photosPhase.querySelector(sel); };
      var video = q("[data-p-video]"), shot = q("[data-p-shot]"), empty = q("[data-p-empty]"), check = q("[data-p-check]");
      var hud = q("[data-p-hud]"), meter = q("[data-p-meter]"), msg = q("[data-p-msg]"), ring = q("[data-p-ring]"), thumbs = q("[data-p-thumbs]");
      var bStart = q("[data-p-start]"), bCap = q("[data-p-capture]"), bRetake = q("[data-p-retake]"), bNext = q("[data-p-next]"), file = q("[data-p-file]"), bSkip = q("[data-p-skip]");
      var stopLoop = function () { if (loop) cancelAnimationFrame(loop); loop = null; };
      var stop = function () { stopLoop(); if (stream) { stream.getTracks().forEach(function (t) { t.stop(); }); stream = null; } };
      var manual = function () { return trackerFailed || !tracker; };
      var show = function (state) {
        video.hidden = state !== "live"; shot.hidden = state !== "shot"; empty.hidden = state !== "idle"; check.hidden = state !== "shot";
        if (hud) hud.hidden = state !== "live";
        bStart.hidden = state !== "idle"; bCap.hidden = !(state === "live" && manual()); bRetake.hidden = state !== "shot"; bNext.hidden = state !== "shot";
        photosPhase.setAttribute("data-state", state);
      };
      var render = function () {
        var s = slots[idx]; hold = 0; attempts = 0;
        q("[data-p-count]").textContent = "Face scan · " + pad(idx + 1) + "/" + pad(slots.length);
        q("[data-p-num]").textContent = pad(idx + 1);
        q("[data-p-bar]").style.width = ((idx + 1) / slots.length) * 100 + "%";
        q("[data-p-title]").textContent = s.title; q("[data-p-hint]").textContent = s.hint;
        photosPhase.querySelectorAll("[data-p-step]").forEach(function (li, i) { li.setAttribute("data-state", i < idx ? "done" : i === idx ? "active" : ""); });
        photosPhase.setAttribute("data-pose", s.pose);
        if (ring) ring.style.setProperty("--p", 0);
        if (thumbs) thumbs.querySelectorAll("[data-p-thumb]").forEach(function (t, i) { var sh = shots[slots[i].id]; if (sh) { t.style.backgroundImage = "url(" + sh.url + ")"; t.setAttribute("data-done", ""); } else { t.style.backgroundImage = ""; t.removeAttribute("data-done"); } t.toggleAttribute("data-active", i === idx); });
        show(stream ? "live" : "idle");
      };
      var quality = function (img) {
        var c = document.createElement("canvas"), w = 96, h = Math.round(96 * (img.naturalHeight || img.videoHeight) / (img.naturalWidth || img.videoWidth)) || 128;
        c.width = w; c.height = h; var ctx = c.getContext("2d"); ctx.drawImage(img, 0, 0, w, h);
        var d = ctx.getImageData(0, 0, w, h).data, g = new Float32Array(w * h), sum = 0;
        for (var i = 0; i < w * h; i++) { g[i] = 0.299 * d[i * 4] + 0.587 * d[i * 4 + 1] + 0.114 * d[i * 4 + 2]; sum += g[i]; }
        var mean = sum / (w * h), lap = 0, n = 0;
        for (var y = 1; y < h - 1; y++) for (var x = 1; x < w - 1; x++) { var k = y * w + x; var v = 4 * g[k] - g[k - 1] - g[k + 1] - g[k - w] - g[k + w]; lap += v * v; n++; }
        return { light: mean, sharp: lap / n, lightOk: mean > 60 && mean < 205, sharpOk: lap / n > 35 };
      };
      var toDataUrl = function (src, sw, sh) {
        var max = 720, r = Math.min(1, max / Math.max(sw, sh)), c = document.createElement("canvas");
        c.width = Math.round(sw * r); c.height = Math.round(sh * r); c.getContext("2d").drawImage(src, 0, 0, c.width, c.height);
        return c.toDataURL("image/jpeg", 0.82);
      };
      var flash = function () { photosPhase.classList.add("is-flash"); setTimeout(function () { photosPhase.classList.remove("is-flash"); }, 350); };
      var finish = function () {
        stop();
        if (Object.keys(shots).length) { try { localStorage.setItem("aestheticPhotos", JSON.stringify({ takenAt: new Date().toISOString(), shots: shots })); } catch (e) {} }
        startAnalysis(photosPhase);
      };
      var accept = function (rec) {
        shots[slots[idx].id] = rec;
        if (idx < slots.length - 1) { idx++; render(); if (stream && !manual()) startLoop(); }
        else { render(); if (msg) msg.textContent = "Scan complete"; setTimeout(finish, 600); }
      };
      /* Automatic capture: quality-checked, retried up to three times before accepting anyway. */
      var autoCapture = function () {
        if (!video.videoWidth) return;
        var qy = quality(video), rec = { url: toDataUrl(video, video.videoWidth, video.videoHeight), light: Math.round(qy.light), sharp: Math.round(qy.sharp), ok: qy.lightOk && qy.sharpOk, auto: true };
        attempts++;
        if (!rec.ok && attempts < 3) { if (msg) msg.textContent = !qy.lightOk ? (qy.light <= 60 ? "Too dark, face a window" : "Too bright, step out of direct light") : "Hold still, a bit blurry"; hold = 0; return; }
        flash(); accept(rec);
      };
      /* Manual capture (no tracking): review the photo, then use or retake. */
      var review = function (src, sw, sh) {
        stopLoop();
        var url = toDataUrl(src, sw, sh); shot.src = url;
        var qy = quality(src);
        q("[data-p-light]").setAttribute("data-ok", qy.lightOk); q("[data-p-light] span:last-child").textContent = qy.lightOk ? "Good light" : (qy.light <= 60 ? "Too dark, face a window" : "Too bright, step out of direct light");
        q("[data-p-sharp]").setAttribute("data-ok", qy.sharpOk); q("[data-p-sharp] span:last-child").textContent = qy.sharpOk ? "Sharp" : "Blurry, hold still and retake";
        pending = { url: url, ok: qy.lightOk && qy.sharpOk, light: Math.round(qy.light), sharp: Math.round(qy.sharp), auto: false };
        bNext.querySelector("span").textContent = pending.ok ? "Use this photo →" : "Use it anyway →";
        show("shot"); flash();
      };
      /* Face tracking: head yaw from landmarks (nose tip between the two cheek edges). ~0.5 = front, → 1 = turned left, → 0 = turned right. */
      var loadTracker = function () {
        if (tracker || trackerFailed) return Promise.resolve(tracker);
        if (msg) msg.textContent = "Loading face tracking…";
        var base = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14";
        return import(base + "/vision_bundle.mjs").then(function (mod) {
          return mod.FilesetResolver.forVisionTasks(base + "/wasm").then(function (fs) {
            return mod.FaceLandmarker.createFromOptions(fs, { baseOptions: { modelAssetPath: "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task", delegate: "GPU" }, runningMode: "VIDEO", numFaces: 1 });
          });
        }).then(function (lm) { tracker = lm; return lm; }).catch(function () { trackerFailed = true; if (msg) msg.textContent = "Automatic scan unavailable here. Take the three photos with the button."; show("live"); return null; });
      };
      var measure = function () {
        if (!tracker || !video.videoWidth) return null;
        var now = performance.now(); if (now - lastTs < 60) return undefined; lastTs = now;
        var res = tracker.detectForVideo(video, now);
        var f = res && res.faceLandmarks && res.faceLandmarks[0]; if (!f) return null;
        var nose = f[1], a = f[234], b = f[454];
        var width = Math.abs(b.x - a.x); if (width < 0.12) return { small: true };
        return { r: (nose.x - Math.min(a.x, b.x)) / width, mirrored: b.x < a.x };
      };
      var target = function (pose, r) {
        if (pose === "front") return { ok: r > 0.4 && r < 0.6, dir: r < 0.4 ? "Turn slightly to the right" : r > 0.6 ? "Turn slightly to the left" : "Hold still" };
        if (pose === "left") return { ok: r > 0.78, dir: r > 0.78 ? "Hold it there" : "Keep turning to the left" };
        return { ok: r < 0.22, dir: r < 0.22 ? "Hold it there" : "Keep turning to the right" };
      };
      var tick = function () {
        loop = requestAnimationFrame(tick);
        if (capturing) return;
        var m = measure(); if (m === undefined) return;
        var s = slots[idx];
        if (!m) { hold = 0; if (msg) msg.textContent = "Center your face in the frame"; if (meter) meter.style.setProperty("--r", 0.5); if (ring) ring.style.setProperty("--p", 0); return; }
        if (m.small) { hold = 0; if (msg) msg.textContent = "Move a little closer"; return; }
        var r = m.mirrored ? 1 - m.r : m.r, t = target(s.pose, r);
        if (meter) meter.style.setProperty("--r", r);
        if (t.ok) hold += 1; else hold = Math.max(0, hold - 2);
        var need = 12;
        if (ring) ring.style.setProperty("--p", Math.min(1, hold / need));
        if (msg) msg.textContent = t.ok ? "Hold still…" : t.dir;
        if (hold >= need) { capturing = true; hold = 0; setTimeout(function () { autoCapture(); capturing = false; }, 80); }
      };
      var startLoop = function () { stopLoop(); lastTs = 0; hold = 0; if (tracker) loop = requestAnimationFrame(tick); };
      bStart.addEventListener("click", function () {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { q("[data-p-empty] p").textContent = "Camera not available here. Upload your three photos instead."; trackerFailed = true; return; }
        navigator.mediaDevices.getUserMedia({ video: { facingMode: "user", width: { ideal: 1280 }, height: { ideal: 1600 } }, audio: false })
          .then(function (s) { stream = s; video.srcObject = s; show("live"); if (msg) msg.textContent = "Starting…"; return loadTracker(); })
          .then(function () { if (stream) { show("live"); startLoop(); } })
          .catch(function () { q("[data-p-empty] p").textContent = "Camera access was refused. Upload a photo instead."; });
      });
      bCap.addEventListener("click", function () { if (video.videoWidth) review(video, video.videoWidth, video.videoHeight); });
      file.addEventListener("change", function () {
        var f = file.files && file.files[0]; if (!f) return;
        var img = new Image(); img.onload = function () { review(img, img.naturalWidth, img.naturalHeight); URL.revokeObjectURL(img.src); }; img.src = URL.createObjectURL(f); file.value = "";
      });
      bRetake.addEventListener("click", function () { pending = null; show(stream ? "live" : "idle"); if (stream && !manual()) startLoop(); });
      bNext.addEventListener("click", function () {
        if (!pending) return; var rec = pending; pending = null; accept(rec);
      });
      bSkip.addEventListener("click", finish);
      render();
    };
    var analysisRunning = false;
    var startAnalysis = function (fromPhase) {
      if (analysisRunning || !A.isComplete(answers)) return;
      analysisRunning = true;
      var ranked = A.compute(answers);
      A.persist(answers, ranked, product.handle ? product : null);
      swap((fromPhase && fromPhase.nodeType) ? fromPhase : phases.quiz, phases.analysis, function () {
        runAnalysis(phases.analysis, function () { swap(phases.analysis, phases.results, function () { renderResults(ranked, true); }); });
      });
    };


    /* Full analysis: face / skin / physique, written from the answers and the day-0 scan. Least effort, most result. */
    var analysisHTML = function (ans, scan, ranked) {
      ans = ans || {}; var m = (scan && scan.metrics) || {};
      var num = function (v) { return typeof v === "number"; };
      var sec = function (title, tag, where, plan, expect) {
        return '<div class="res__an"><div class="res__an-head"><p class="res__an-title">' + title + '</p><span class="res__an-tag">' + tag + '</span></div>' +
          '<p class="res__an-p"><strong>Where you are.</strong> ' + where + '</p><p class="res__an-p"><strong>What we do.</strong> ' + plan + '</p><p class="res__an-p"><strong>What you see.</strong> ' + expect + '</p></div>';
      };
      /* face */
      var fw = [];
      if (num(m.gonial)) fw.push(m.gonial < 122 ? "Your gonial angle reads sharp (" + m.gonial + "°). The bone is there; what hides it on some days is water and chin posture." : m.gonial < 132 ? "Your gonial angle is defined (" + m.gonial + "°) but softened by swelling and the way you carry your chin." : "Your gonial angle reads soft (" + m.gonial + "°). Most of that is water retention, neck posture and jaw carriage, not bone. That is the part that moves fastest.");
      if (num(m.jawRatio) && m.jawRatio < 0.72) fw.push("Your jaw sits narrower than your cheekbones: the lower face needs to fill the frame.");
      if (m.thirds && m.thirds[2] > 37) fw.push("Your lower third runs slightly long, usually mouth posture and a chin held low.");
      if (num(m.canthal)) fw.push(m.canthal > 2 ? "Canthal tilt is positive, which reads alert and rested. Keep it that way: sleep and de-puffing." : m.canthal < -2 ? "Canthal tilt is slightly negative. Puffiness and short sleep exaggerate it; that is what we remove." : "Canthal tilt is neutral; the eye area will read sharper as soon as the puffiness drops.");
      if (!fw.length) fw.push(ans.photo === "jaw" ? "You said your jaw is what you notice in group photos. That is a water, posture and chin-carriage problem before it is a bone problem." : "No scan on file, so we work from your answers: the jaw and the eye area are where the first visible changes land.");
      if (ans.age === "35-44" || ans.age === "45+") fw.push("At your age, the fastest visual win is around the eyes and the jaw-neck line, not the forehead.");
      var face = sec("Face", "Jawline · eyes · profile", fw.join(" "),
        "Six minutes every morning: chin posture, tongue posture, neck and jaw carriage. Sodium and water timing, a fixed sleep window. No device, no gadget, nothing to buy.",
        "Less puffiness within the first week. The angle and the eye area show by week four. Photos start to read differently before anyone can say why.");
      /* skin */
      var sw = [];
      sw.push(ans.routine === "none" ? "Right now your skin gets nothing. That is the easiest win on the entire list: a blank slate responds fast." : ans.routine === "soap" ? "Water and soap strips the barrier, which is why texture and redness never settle. Easy fix." : ans.routine === "basic" ? "Cleanser and moisturizer is a base. What is missing is the one active that changes texture and tone." : "You already run actives. We cut what does not earn its place and fix the order, which is usually the problem.");
      if (ans.photo === "skin") sw.push("You notice it in photos; so does everyone, which is why it ranks high.");
      if (ans.age === "35-44" || ans.age === "45+") sw.push("Sun protection and a retinoid become non-negotiable from here.");
      if (ans.age === "18-24") sw.push("At your age, consistency beats strength: the mild version, every day, wins.");
      var skin = sec("Skin", "Texture · tone · redness", sw.join(" "),
        "Three products, morning and night, two minutes total. The exact order, the exact amounts. Nothing else added until week four.",
        "Redness and texture calm within a week. Tone evens by week four. Under good light it is the first thing people notice.");
      /* physique */
      var pw = [];
      pw.push(ans.training === "0" ? "You train zero times a week. That is not a problem, it is the biggest lever you have not touched." : ans.training === "1-2" ? "One or two sessions a week: enough to start, not enough to change a t-shirt yet." : ans.training === "3-4" ? "You already train. We redirect the volume to shoulders, upper back and neck, the muscles that change the frame of your face." : ans.training === "5+" ? "You train more than most. The return now is in food and water, not more sessions." : "We work from the mirror, not the scale.");
      if (ans.photo === "body") pw.push("It is what you notice first in group photos, so it is what we make visible first.");
      if (ans.time === "u1h") pw.push("You said under an hour a week. Everything below fits inside that.");
      var sessions = ans.time === "u1h" ? "Two 25-minute sessions" : ans.time === "1-3h" ? "Two or three 35-minute sessions" : "Three 40-minute sessions";
      if (ans.time === "1-3h") pw.push("One to three hours a week is exactly the budget this is built for.");
      var phys = sec("Physique", "Frame · water · fat", pw.join(" "),
        sessions + ": shoulders, upper back, neck. Lean-face recipes, sodium and water timing. No cardio marathons, no diet you cannot hold.",
        "The face de-puffs first, in the first two weeks. Then the neck and shoulders fill the frame by week six to eight.");
      /* what they tried + order */
      var tried = ans.tried === "products" ? "You tried products before and they did not hold. They were never sequenced, that is all." : ans.tried === "youtube" ? "YouTube gave you pieces, never the order. The order is the product." : ans.tried === "gym" ? "The gym changed the body and left the face. This time the face comes first." : ans.tried === "never" ? "You never tried anything. Good: no bad habits to unlearn." : "";
      var order = ranked && ranked.length ? "Your order: " + ranked.slice(0, 3).map(function (p, i) { return (i + 1) + ". " + p.name; }).join("  ·  ") + ". Do it in this order. Each one makes the next easier." : "";
      return face + skin + phys + '<div class="res__an-order">' + (tried ? tried + " " : "") + order + "</div>";
    };
    /* Results */
    var revealArmed = false;
    var renderResults = function (ranked, animate) {
      var prof = A.profile(answers);
      ranked.slice(0, 3).forEach(function (p, i) {
        var card = assess.querySelector('[data-r-card="' + i + '"]'); if (!card) return;
        card.querySelector("[data-r-label]").textContent = A.rankLabels[i];
        card.querySelector("[data-r-name]").textContent = p.name;
        var mt = card.querySelector("[data-r-match]"); if (mt) mt.textContent = A.matchLabels[i];
        var why = card.querySelector("[data-r-why]"); if (why) why.textContent = i === 0 ? p.why : p.why + " " + p.rankCopy;
        var b = card.querySelector("[data-r-bar]"); b.style.width = "0%"; setTimeout(function () { b.style.width = Math.max(10, p.score) + "%"; }, 400 + i * 150);
      });
      var setTxt = function (sel, v) { var el = assess.querySelector(sel); if (el) el.textContent = v; };
      setTxt("[data-r-p-top]", ranked[0].name); setTxt("[data-r-p-goal]", prof.goal || "—"); setTxt("[data-r-p-commit]", prof.commitment || "—");
      var strip = assess.querySelector("[data-r-photos]");
      if (strip) { try { var ph = JSON.parse(localStorage.getItem("aestheticPhotos") || "null"); if (ph && ph.shots) { var any = false; strip.querySelectorAll("[data-r-photo]").forEach(function (im) { var sh = ph.shots[im.getAttribute("data-r-photo")]; if (sh) { im.src = sh.url; im.hidden = false; any = true; } else im.hidden = true; }); strip.hidden = !any; } } catch (e) {} }
      var conf = assess.querySelector("[data-r-p-conf]"); if (conf) conf.textContent = prof.confidence ? prof.confidence.split(".")[0] : "—";
      /* Day-0 scan card (annotated photos + measurements, from the device only) */
      var scanBox = assess.querySelector("[data-r-scan]"), scan = window.AL_FACE_SCAN ? window.AL_FACE_SCAN.load() : null;
      if (scanBox && scan && (scan.front || scan.angle)) {
        var m = scan.metrics || {};
        var tilt = typeof m.canthal === "number" ? (m.canthal > 2 ? "Slightly upturned" : m.canthal < -2 ? "Slightly downturned" : "Neutral") : "";
        var gon = typeof m.gonial === "number" ? (m.gonial < 122 ? "Sharp, well-defined" : m.gonial < 132 ? "Defined" : "Softer angle") : "";
        var sym = typeof m.symmetry === "number" ? m.symmetry + "%" : "";
        var thirds = m.thirds ? m.thirds.join(" / ") : "";
        var img = function (rec, cls) { return rec ? '<figure class="res__scan-img ' + cls + '"><img src="' + (rec.annotated || rec.url) + '" alt=""></figure>' : ""; };
        scanBox.querySelector("[data-r-scan-imgs]").innerHTML = img(scan.front, "is-front") + img(scan.angle, "is-angle");
        var rows = [];
        if (gon) rows.push(["Jawline (gonial angle)", m.gonial + "°", gon]);
        if (tilt) rows.push(["Canthal tilt", (m.canthal > 0 ? "+" : "") + m.canthal + "°", tilt]);
        if (sym) rows.push(["Symmetry", sym, m.symmetry >= 90 ? "Very balanced" : m.symmetry >= 80 ? "Balanced" : "Some asymmetry, mostly posture and expression"]);
        if (thirds) rows.push(["Facial thirds", thirds, "upper / middle / lower"]);
        if (typeof m.jawRatio === "number") rows.push(["Jaw width vs cheekbones", m.jawRatio, m.jawRatio >= 0.8 ? "Strong lower face" : m.jawRatio >= 0.7 ? "Balanced" : "Room to sharpen"]);
        scanBox.querySelector("[data-r-scan-rows]").innerHTML = rows.map(function (r) { return '<div class="res__scan-row"><span class="res__scan-k">' + r[0] + '</span><span class="res__scan-v tnum">' + r[1] + '</span><span class="res__scan-t">' + r[2] + '</span></div>'; }).join("");
        scanBox.hidden = false;
      }
      var anBox = assess.querySelector("[data-r-analysis]");
      if (anBox) { try { anBox.innerHTML = analysisHTML(answers, scan, ranked); anBox.hidden = false; } catch (e) {} }
      /* Email gate on the last two priorities */
      var gate = assess.querySelector("[data-r-gate]");
      if (gate) {
        var unlocked = false; try { unlocked = localStorage.getItem("aestheticUnlocked") === "1"; } catch (e) {}
        var prio = assess.querySelector(".res__prio");
        var setLocked = function (locked) { if (prio) prio.classList.toggle("is-locked", locked); gate.hidden = !locked; };
        setLocked(!unlocked);
        var gform = gate.querySelector("form");
        if (gform && !gform.getAttribute("data-bound")) {
          gform.setAttribute("data-bound", "1");
          gform.addEventListener("submit", function (e) {
            e.preventDefault();
            var email = gform.querySelector("[type=email]"); if (!email || !email.value || email.value.indexOf("@") < 0) { if (email) email.focus(); return; }
            var btn = gform.querySelector("[type=submit]"); if (btn) { btn.disabled = true; btn.querySelector("span").textContent = "Unlocking…"; }
            fetch(gform.getAttribute("action"), { method: "POST", body: new FormData(gform), headers: { Accept: "text/html" } })
              .catch(function () {}).then(function () { try { localStorage.setItem("aestheticUnlocked", "1"); localStorage.setItem("aestheticEmail", email.value); } catch (e) {} setLocked(false); });
          });
        }
      }
      var top3 = assess.querySelector("[data-r-top3]");
      if (top3 && top3.hasAttribute("data-pills")) top3.innerHTML = ranked.slice(0, 3).map(function (p) { return '<span>' + p.name + "</span>"; }).join("");
      else if (top3) top3.innerHTML = top3.tagName === "OL" ? ranked.slice(0, 3).map(function (p, i) { return '<li><span class="eyebrow tnum">' + pad(i + 1) + "</span><span>" + p.name + "</span></li>"; }).join("") : ranked.slice(0, 3).map(function (p) { return "<strong>" + p.name + "</strong>"; }).join(" · ");
      var single = assess.querySelector("[data-r-single]"), singleLink = assess.querySelector("[data-r-single-link]");
      if (single && ranked[0].handle && ranked[0].handle !== product.handle) {
        fetch("/products/" + ranked[0].handle + ".js").then(function (r) { return r.ok ? r.json() : null; }).then(function (pr) {
          if (!pr) return; singleLink.textContent = pr.title + " · " + money(pr.price); singleLink.setAttribute("href", "/products/" + pr.handle); single.hidden = false;
        }).catch(function () {});
      }
      if (animate && !reduce) assess.querySelectorAll("[data-res-in]").forEach(function (el, i) { el.style.animationDelay = (i * 110) + "ms"; el.classList.add("res-in"); });
      else assess.querySelectorAll("[data-res-in]").forEach(function (el) { el.style.opacity = 1; });

      var reveal = assess.querySelector("[data-r-reveal]"), card = assess.querySelector("[data-r-match-card]");
      var play = function () {
        if (revealArmed) return; revealArmed = true;
        if (!reveal) { card.classList.add("is-on"); return; }
        reveal.querySelector("[data-r-reveal-1]").classList.add("is-on");
        setTimeout(function () { reveal.querySelector("[data-r-reveal-2]").classList.add("is-on"); }, reduce ? 0 : 600);
        setTimeout(function () { card.classList.add("is-on"); }, reduce ? 0 : 1250);
      };
      if (reveal && "IntersectionObserver" in window && !reduce) {
        new IntersectionObserver(function (entries, obs) { if (entries[0].isIntersecting) { play(); obs.disconnect(); } }, { rootMargin: "0px 0px -20% 0px" }).observe(reveal);
      } else play();

      /* Unlock: add to cart, confirm, update the count, then the product page. */
      var go = function () { window.location.href = product.url || assess.getAttribute("data-protocols-url"); };
      var unlockFlow = function (btn, label) {
        if (btn.getAttribute("data-state")) return;
        assess.querySelectorAll("[data-r-unlock], [data-r-sticky-unlock]").forEach(function (b) { b.setAttribute("data-state", "loading"); });
        label.textContent = "Unlocking your protocol…";
        if (!product.variant) return setTimeout(go, 500);
        fetch("/cart/add.js", { method: "POST", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify({ items: [{ id: product.variant, quantity: 1 }] }) })
          .then(function (r) { if (!r.ok) throw new Error("add failed"); return r.json(); })
          .then(function () { return refreshCart().catch(function () {}); })
          .then(function () { assess.querySelectorAll("[data-r-unlock], [data-r-sticky-unlock]").forEach(function (b) { b.setAttribute("data-state", "done"); }); label.textContent = "Protocol unlocked ✓"; setTimeout(go, 550); })
          .catch(go);
      };
      var unlock = assess.querySelector("[data-r-unlock]");
      if (unlock && !unlock.getAttribute("data-bound")) { unlock.setAttribute("data-bound", "1"); unlock.addEventListener("click", function () { unlockFlow(unlock, unlock.querySelector("[data-r-unlock-label]")); }); }
      var sticky = assess.querySelector("[data-r-sticky]"), stickyBtn = assess.querySelector("[data-r-sticky-unlock]");
      if (sticky && stickyBtn && !stickyBtn.getAttribute("data-bound")) {
        stickyBtn.setAttribute("data-bound", "1");
        stickyBtn.addEventListener("click", function () { unlockFlow(stickyBtn, stickyBtn.querySelector("span")); });
        var cta = unlock || card;
        if ("IntersectionObserver" in window) {
          new IntersectionObserver(function (entries) { var e = entries[0]; sticky.setAttribute("data-visible", String(!e.isIntersecting)); }).observe(cta);
        }
        setTimeout(function () { sticky.setAttribute("data-visible", "true"); }, 1400);
      }
      var retake = assess.querySelector("[data-r-retake]");
      if (retake && !retake.getAttribute("data-bound")) {
        retake.setAttribute("data-bound", "1");
        retake.addEventListener("click", function () { A.clear(); window.location.href = assess.getAttribute("data-assessment-url"); });
      }
    };

    if (mode === "results") {
      if (state.completed && A.isComplete(answers)) { phases.results.hidden = false; try { renderResults(A.compute(answers), true); } catch (err) { if (window.console) console.warn("results render", err); } }
      else phases.empty.hidden = false;
    } else {
      try {
        var focus = new URLSearchParams(window.location.search).get("focus");
        if (focus && A.questions[0].options.some(function (o) { return o.id === focus; })) { answers = { focus: focus }; A.saveAnswers(answers); }
      } catch (e) {}
      var first = A.questions.findIndex(function (q) { return !answers[q.id]; });
      step = first === -1 ? 0 : first;
      renderQuiz();
    }
  }

  /* Product page: personalised match block for customers who completed the assessment. */
  var pm = document.querySelector("[data-ai-match]");
  if (pm && window.AL_ASSESSMENT) {
    var st = window.AL_ASSESSMENT.loadState();
    if (st.completed && st.top) {
      var handle = pm.getAttribute("data-handle");
      var handles = [st.product && st.product.handle, st.top.handle, st.second && st.second.handle, st.third && st.third.handle].filter(Boolean);
      if (handles.indexOf(handle) !== -1) { pm.querySelector("[data-ai-match-top]").textContent = st.top.name; pm.hidden = false; }
    }
  }
})();

/* Lazy background videos: poster paints first, the video loads once near the viewport, pauses when off-screen. */
(function () {
  var vids = document.querySelectorAll("video[data-lazy-video]");
  if (!vids.length) return;
  var mobile = window.matchMedia("(max-width: 767px)").matches;
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var saveData = navigator.connection && navigator.connection.saveData;
  if (reduce || saveData) return;
  var load = function (v) {
    if (v.getAttribute("src")) return;
    var src = (mobile && v.getAttribute("data-src-mobile")) || v.getAttribute("data-src");
    if (!src) return;
    v.addEventListener("playing", function () { v.classList.add("is-playing"); }, { once: true });
    v.setAttribute("src", src);
    var p = v.play(); if (p && p.catch) p.catch(function () {});
  };
  if (!("IntersectionObserver" in window)) { vids.forEach(load); return; }
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      var v = e.target;
      if (e.isIntersecting) { load(v); if (v.paused) { var p = v.play(); if (p && p.catch) p.catch(function () {}); } }
      else if (v.getAttribute("src") && !v.paused) v.pause();
    });
  }, { rootMargin: "240px 0px" });
  vids.forEach(function (v) { io.observe(v); });
})();

/* Product page extras: quantity stepper, mobile sticky buy bar, share link. */
(function () {
  document.addEventListener("click", function (e) {
    var b = e.target.closest("[data-qty]"); if (!b) return;
    var input = b.parentElement.querySelector("input"); if (!input) return;
    var v = (parseInt(input.value, 10) || 1) + (b.getAttribute("data-qty") === "+" ? 1 : -1);
    input.value = Math.max(1, v);
  });
  var sticky = document.querySelector("[data-p-sticky]"), form = document.getElementById("primary-cta");
  if (sticky && form && "IntersectionObserver" in window) {
    new IntersectionObserver(function (entries) {
      var e = entries[0];
      sticky.setAttribute("data-visible", String(!e.isIntersecting && e.boundingClientRect.top < 0));
    }).observe(form);
  }
  var initShare = function (scope) { (scope || document).querySelectorAll("[data-share]").forEach(function (b) {
    if (b.getAttribute("data-init")) return; b.setAttribute("data-init", "1");
    b.addEventListener("click", function () {
      var url = b.getAttribute("data-share-url") || location.href, title = b.getAttribute("data-share-title") || document.title, label = b.querySelector("[data-share-label]");
      if (navigator.share) { navigator.share({ title: title, url: url }).catch(function () {}); return; }
      if (navigator.clipboard) navigator.clipboard.writeText(url).then(function () { if (label) { var t = label.textContent; label.textContent = "Link copied"; setTimeout(function () { label.textContent = t; }, 1800); } });
    });
  }); };
  initShare(document); (window.AL_SCOPE_INITS = window.AL_SCOPE_INITS || []).push(initShare);
})();

/* Pop-up before/after: rotate between pairs every few seconds, only while visible. */
(function () {
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  document.querySelectorAll("[data-qc-ba]").forEach(function (box) {
    var pairs = box.querySelectorAll("[data-qc-pair]"), dots = box.querySelectorAll(".qc__ba-dots span");
    if (pairs.length < 2 || reduce) return;
    var i = 0, timer = null, interval = parseInt(box.getAttribute("data-interval"), 10) || 3000;
    var root = box.closest("[data-quickcheck]");
    var show = function (n) {
      pairs[i].classList.remove("is-active"); pairs[i].classList.add("is-leaving");
      var prev = pairs[i]; setTimeout(function () { prev.classList.remove("is-leaving"); }, 700);
      i = n % pairs.length; pairs[i].classList.add("is-active");
      dots.forEach(function (d, k) { d.classList.toggle("is-on", k === i); });
    };
    var start = function () { if (timer) return; timer = setInterval(function () { show(i + 1); }, interval); };
    var stop = function () { clearInterval(timer); timer = null; };
    var sync = function () { var open = !root || root.getAttribute("data-open") === "true"; if (open && !document.hidden && box.offsetParent) start(); else stop(); };
    if (root) new MutationObserver(sync).observe(root, { attributes: true, attributeFilter: ["data-open", "data-qc-state"] });
    var phase = box.closest("[data-qc-phase], [data-phase]");
    if (phase) new MutationObserver(sync).observe(phase, { attributes: true, attributeFilter: ["hidden"] });
    document.addEventListener("visibilitychange", sync);
    sync();
  });
})();

/* Story bubbles: Instagram-style viewer (progress bars, tap to navigate, hold to pause, swipe down to close). */
(function () {
  var initStories = function (scope) { (scope || document).querySelectorAll("[data-stories]").forEach(function (root) {
    if (root.getAttribute("data-init")) return; root.setAttribute("data-init", "1");
    var viewer = root.querySelector("[data-story-viewer]"); if (!viewer) return;
    var slides = Array.prototype.slice.call(viewer.querySelectorAll("[data-story-slide]"));
    var bars = Array.prototype.slice.call(viewer.querySelectorAll("[data-story-bar]"));
    var nameEl = viewer.querySelector("[data-story-name]"), capEl = viewer.querySelector("[data-story-caption]"), avatar = viewer.querySelector("[data-story-avatar]");
    var pausedEl = viewer.querySelector("[data-story-paused]"), card = viewer.querySelector("[data-story-card]");
    var cur = -1, video = null, muted = false, holdTimer = null, lastFocus = null;
    var stop = function () { if (video) { video.pause(); video.removeAttribute("data-live"); video.currentTime = 0; } video = null; };
    var paint = function () { bars.forEach(function (b, i) { b.style.width = i < cur ? "100%" : i > cur ? "0%" : b.style.width; }); };
    var tick = function () { if (video && video.duration) bars[cur].style.width = (video.currentTime / video.duration * 100) + "%"; };
    var tryPlay = function () {
      if (!video) return;
      video.muted = muted;
      var p = video.play();
      if (p && p.catch) p.catch(function () { muted = true; viewer.classList.add("is-muted"); video.muted = true; video.play().catch(function () {}); });
    };
    var stage = viewer.querySelector("[data-story-stage]"), sliding = false;
    var slideTo = function (dir) {
      if (sliding) return;
      var target = cur + dir;
      if (target < 0) { show(0); return; }
      if (target >= slides.length) { close(); return; }
      sliding = true;
      stage.classList.add("is-sliding"); stage.style.transform = "translateX(" + (-dir * 100) + "%)";
      setTimeout(function () {
        show(target);
        stage.classList.remove("is-sliding"); stage.style.transform = "translateX(" + (dir * 100) + "%)";
        requestAnimationFrame(function () { requestAnimationFrame(function () { stage.classList.add("is-sliding"); stage.style.transform = ""; setTimeout(function () { stage.classList.remove("is-sliding"); sliding = false; }, 300); }); });
      }, 280);
    };
    var show = function (i) {
      if (i < 0 || i >= slides.length) { close(); return; }
      stop(); cur = i;
      slides.forEach(function (s, k) { s.hidden = k !== i; });
      bars.forEach(function (b, k) { b.style.width = k < i ? "100%" : "0%"; });
      var s = slides[i];
      nameEl.textContent = s.getAttribute("data-name") || ""; capEl.textContent = s.getAttribute("data-caption") || "";
      avatar.style.backgroundImage = s.getAttribute("data-poster") ? "url(" + s.getAttribute("data-poster") + ")" : "";
      video = s.querySelector("video");
      if (!video) { setTimeout(function () { if (cur === i) show(i + 1); }, 3000); return; }
      video.setAttribute("playsinline", ""); video.loop = false; video.controls = false; video.currentTime = 0;
      video.ontimeupdate = tick; video.onended = function () { show(cur + 1); };
      tryPlay();
      var nxt = slides[i + 1] && slides[i + 1].querySelector("video"); if (nxt && nxt.preload !== "auto") nxt.preload = "auto";
    };
    var open = function (i) {
      lastFocus = document.activeElement;
      viewer.hidden = false; viewer.setAttribute("aria-hidden", "false"); document.body.classList.add("story-open");
      requestAnimationFrame(function () { viewer.classList.add("is-open"); });
      viewer.classList.toggle("is-muted", muted);
      show(i);
    };
    var close = function () {
      stop(); viewer.classList.remove("is-open"); document.body.classList.remove("story-open");
      setTimeout(function () { viewer.hidden = true; viewer.setAttribute("aria-hidden", "true"); card.style.transform = ""; }, 300);
      if (lastFocus && lastFocus.focus) lastFocus.focus();
    };
    root.querySelectorAll("[data-story-open]").forEach(function (b) { b.addEventListener("click", function () { open(parseInt(b.getAttribute("data-story-open"), 10) || 0); }); });
    viewer.querySelectorAll("[data-story-close]").forEach(function (b) { b.addEventListener("click", close); });
    viewer.querySelector("[data-story-mute]").addEventListener("click", function () { muted = !muted; viewer.classList.toggle("is-muted", muted); if (video) video.muted = muted; });
    /* tap = navigate, hold = pause */
    var bindZone = function (zone, dir) {
      var held = false;
      zone.addEventListener("pointerdown", function (e) { held = false; holdTimer = setTimeout(function () { held = true; if (video) video.pause(); pausedEl.hidden = false; }, 220); });
      zone.addEventListener("pointerup", function () { clearTimeout(holdTimer); if (held) { pausedEl.hidden = true; tryPlay(); } else if (!swiped) slideTo(dir); });
      zone.addEventListener("pointerleave", function () { clearTimeout(holdTimer); if (held) { held = false; pausedEl.hidden = true; tryPlay(); } });
    };
    bindZone(viewer.querySelector("[data-story-prev]"), -1); bindZone(viewer.querySelector("[data-story-next]"), 1);
    /* swipe: horizontal = previous / next story (fluid slide), down = close */
    var sx = null, sy = null, axis = null, swiped = false;
    card.addEventListener("touchstart", function (e) { sx = e.touches[0].clientX; sy = e.touches[0].clientY; axis = null; swiped = false; }, { passive: true });
    card.addEventListener("touchmove", function (e) {
      if (sx === null) return;
      var dx = e.touches[0].clientX - sx, dy = e.touches[0].clientY - sy;
      if (!axis && (Math.abs(dx) > 8 || Math.abs(dy) > 8)) axis = Math.abs(dx) > Math.abs(dy) ? "x" : "y";
      if (axis === "x") { swiped = true; clearTimeout(holdTimer); stage.style.transform = "translateX(" + dx + "px)"; }
      else if (axis === "y" && dy > 0) card.style.transform = "translateY(" + dy * 0.6 + "px)";
    }, { passive: true });
    card.addEventListener("touchend", function (e) {
      var dx = e.changedTouches[0].clientX - (sx || 0), dy = e.changedTouches[0].clientY - (sy || 0);
      if (axis === "x") {
        if (Math.abs(dx) > 60) { stage.style.transform = ""; slideTo(dx < 0 ? 1 : -1); }
        else { stage.classList.add("is-sliding"); stage.style.transform = ""; setTimeout(function () { stage.classList.remove("is-sliding"); }, 300); }
      } else if (axis === "y") { if (dy > 90) close(); else card.style.transform = ""; }
      sx = sy = null; setTimeout(function () { swiped = false; }, 50);
    });
    document.addEventListener("keydown", function (e) { if (viewer.hidden) return; if (e.key === "Escape") close(); if (e.key === "ArrowRight") slideTo(1); if (e.key === "ArrowLeft") slideTo(-1); });
    document.addEventListener("visibilitychange", function () { if (!viewer.hidden && video) { if (document.hidden) video.pause(); else tryPlay(); } });
  }); };
  initStories(document); (window.AL_SCOPE_INITS = window.AL_SCOPE_INITS || []).push(initStories);
})();

/* Countdown timers: [data-countdown="YYYY-MM-DDTHH:MM"] in the visitor's local clock; hides when over if data-hide-expired. */
(function () {
  var pad = function (n) { return String(n).padStart(2, "0"); };
  var tick = function () {
    document.querySelectorAll("[data-countdown]").forEach(function (el) {
      var end = Date.parse(el.getAttribute("data-countdown")); if (isNaN(end)) return;
      var left = Math.max(0, end - Date.now());
      if (left === 0 && el.hasAttribute("data-hide-expired")) { el.setAttribute("data-expired", ""); return; }
      var d = Math.floor(left / 86400000), h = Math.floor(left % 86400000 / 3600000), m = Math.floor(left % 3600000 / 60000), sec = Math.floor(left % 60000 / 1000);
      var dd = el.querySelector("[data-cd=d]"), hh = el.querySelector("[data-cd=h]"), mm = el.querySelector("[data-cd=m]"), ss = el.querySelector("[data-cd=s]");
      if (dd) { dd.hidden = d === 0; dd.textContent = d + "d "; }
      if (hh) hh.textContent = pad(h); if (mm) mm.textContent = pad(m); if (ss) ss.textContent = pad(sec);
    });
  };
  tick(); setInterval(tick, 1000);
})();

/* Results page: embed the real product page (its "Product information" section) in place of the summary card. */
(function () {
  var box = document.querySelector("[data-r-product-embed]"); if (!box) return;
  var url = box.getAttribute("data-product-url"); if (!url) return;
  var started = false;
  var start = function () {
    if (started) return; started = true;
    fetch(url, { credentials: "same-origin" }).then(function (r) { return r.ok ? r.text() : Promise.reject(); }).then(function (html) {
      var doc = new DOMParser().parseFromString(html, "text/html");
      var prod = doc.querySelector("[data-product-section] .product"); if (!prod) return;
      var clean = function (el) { el.querySelectorAll("[data-reveal], [data-text-reveal], [data-countup], [data-parallax]").forEach(function (x) { x.removeAttribute("data-reveal"); x.removeAttribute("data-text-reveal"); x.removeAttribute("data-countup"); x.removeAttribute("data-parallax"); x.style.opacity = ""; }); el.querySelectorAll("script").forEach(function (sc) { sc.remove(); }); };
      clean(prod);
      box.innerHTML = ""; box.appendChild(prod); box.setAttribute("data-embedded", "1");
      if (window.AL_INIT_SCOPE) window.AL_INIT_SCOPE(box);
      /* every other section of the product page (logos, why it works, reviews, before/after, related, FAQ, CTA) */
      var rest = document.querySelector("[data-r-product-rest]"), main = doc.getElementById("MainContent");
      if (rest && main) {
        rest.innerHTML = "";
        Array.prototype.slice.call(main.children).forEach(function (sec) {
          if (sec.querySelector("[data-product-section]")) return;
          clean(sec); sec.querySelectorAll("[id]").forEach(function (n) { n.id = "r-" + n.id; }); if (sec.id) sec.id = "r-" + sec.id;
          rest.appendChild(sec);
        });
        rest.hidden = rest.children.length === 0;
        if (window.AL_INIT_SCOPE) window.AL_INIT_SCOPE(rest);
      }
      var sticky = document.querySelector("[data-r-sticky]"), form = box.querySelector("#primary-cta");
      if (sticky && form && "IntersectionObserver" in window) new IntersectionObserver(function (entries) { var e = entries[0]; sticky.setAttribute("data-visible", String(!e.isIntersecting && e.boundingClientRect.top < 0)); }).observe(form);
      window.dispatchEvent(new Event("resize"));
      if (window.ScrollTrigger) setTimeout(function () { ScrollTrigger.refresh(); }, 100);
    }).catch(function () {});
  };
  var phase = box.closest("[data-phase]");
  if (!phase || !phase.hidden) start();
  else new MutationObserver(function () { if (!phase.hidden) start(); }).observe(phase, { attributes: true, attributeFilter: ["hidden"] });
})();

/* Results page: compact dropdown "or choose a single protocol", inserted right under the buy button of the embedded product (the button itself is untouched). */
(function () {
  var tpl = document.querySelector("[data-r-alt-template]"); if (!tpl) return;
  var app = tpl.closest("[data-assessment]"), A = window.AL_ASSESSMENT; if (!app || !A) return;
  var mainHandle = app.getAttribute("data-product-handle");
  var money = function (cents) { var f = (window.AL_MONEY_FORMAT || "${{amount}}"); var n = (cents / 100).toFixed(2); return f.replace(/\{\{\s*amount(_with_comma_separator|_no_decimals)?\s*\}\}/, function (m, k) { return k === "_with_comma_separator" ? n.replace(".", ",") : k === "_no_decimals" ? String(Math.round(cents / 100)) : n; }).replace(/<[^>]+>/g, ""); };
  var built = false;
  var mount = function (node) {
    var embed = document.querySelector("[data-r-product-embed]"); if (!embed) return false;
    var anchor = embed.querySelector("#primary-cta") || embed.querySelector(".buy__cta") || embed.querySelector(".buy__once") || embed.querySelector(".buy__benefits") || embed.querySelector(".buy__price");
    if (anchor && anchor.parentNode) { anchor.parentNode.insertBefore(node, anchor.nextSibling); return true; }
    embed.appendChild(node); return true;
  };
  var build = function () {
    if (built) return; built = true;
    var st = A.loadState(); var ranked = [st.top, st.second, st.third].filter(function (r) { return r && r.handle && r.handle !== mainHandle; }).slice(0, 3);
    if (!ranked.length) return;
    var tags = ["Your #1 priority", "Your #2 priority", "Your #3 priority"];
    Promise.all(ranked.map(function (r, i) {
      return fetch("/products/" + r.handle + ".js").then(function (x) { return x.ok ? x.json() : null; }).then(function (p) {
        if (!p || !p.variants || !p.variants.length) return null;
        var v = p.variants[0];
        return { handle: p.handle, title: p.title, variant: v.id, price: v.price, priceText: money(v.price), tag: tags[i], image: p.featured_image ? p.featured_image.replace(/(\.[a-z]+)(\?.*)?$/i, "_120x120$1") : null };
      }).catch(function () { return null; });
    })).then(function (items) {
      items = items.filter(Boolean); if (!items.length) return;
      var node = tpl.content.firstElementChild.cloneNode(true);
      var from = node.querySelector("[data-r-alt-from]"); if (from) from.textContent = "from " + money(Math.min.apply(null, items.map(function (i) { return i.price; })));
      node.querySelector("[data-r-alt-list]").innerHTML = items.map(function (o) {
        return '<div class="res-alt__row">' + (o.image ? '<span class="res-alt__img"><img src="' + o.image + '" alt="" loading="lazy"></span>' : "") +
          '<span class="res-alt__body"><span class="res-alt__name">' + o.title + '</span></span>' +
          '<button type="button" class="res-alt__btn" data-alt-variant="' + o.variant + '" data-alt-handle="' + o.handle + '">Start · ' + o.priceText + '</button></div>';
      }).join("");
      node.querySelectorAll("[data-alt-variant]").forEach(function (b) {
        b.addEventListener("click", function () {
          b.setAttribute("data-state", "loading"); b.textContent = "Adding…";
          fetch("/cart/add.js", { method: "POST", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify({ items: [{ id: parseInt(b.getAttribute("data-alt-variant"), 10), quantity: 1 }] }) })
            .then(function (r) { if (!r.ok) throw new Error("add"); return r.json(); })
            .then(function () { if (window.AL_CART) { return window.AL_CART.refresh().then(function () { window.AL_CART.open(); b.removeAttribute("data-state"); b.textContent = "Added"; }); } window.location.href = "/cart"; })
            .catch(function () { window.location.href = "/products/" + b.getAttribute("data-alt-handle"); });
        });
      });
      var embed = document.querySelector("[data-r-product-embed]");
      if (embed && embed.getAttribute("data-embedded")) mount(node);
      else if (embed) new MutationObserver(function (m, obs) { if (embed.getAttribute("data-embedded")) { mount(node); obs.disconnect(); } }).observe(embed, { attributes: true, attributeFilter: ["data-embedded"] });
    });
  };
  var phase = tpl.closest("[data-phase]");
  if (!phase || !phase.hidden) build();
  else new MutationObserver(function () { if (!phase.hidden) build(); }).observe(phase, { attributes: true, attributeFilter: ["hidden"] });
})();

/* Variant picker: pills -> variant id, price, compare-at, sticky bar, gallery image */
(function () {
  var money = function (cents) { var el = document.querySelector("[data-p-price]"); var sample = el ? el.textContent.trim() : "$0.00"; var v = (cents / 100).toFixed(2); var comma = /\d,\d\d(?!\d)/.test(sample); if (comma) v = v.replace(".", ","); var m = sample.match(/^([^\d]*)[\d.,\s]+([^\d]*)$/); return (m ? m[1] : "") + v + (m ? m[2] : ""); };
  var init = function (scope) {
    (scope || document).querySelectorAll("[data-variant-picker]").forEach(function (box) {
      if (box.getAttribute("data-bound")) return; box.setAttribute("data-bound", "1");
      var variants; try { variants = JSON.parse(box.getAttribute("data-variants") || "[]"); } catch (e) { return; }
      var form = box.closest(".product") ? box.closest(".product").querySelector("form[data-type=add-to-cart-form]") : document.querySelector("form[data-type=add-to-cart-form]");
      var fields = Array.prototype.slice.call(box.querySelectorAll("[data-option-index]"));
      var selected = function () { return fields.map(function (f) { var on = f.querySelector("input:checked"); return on && on.value !== "__bundle__" ? on.value : null; }); };
      var find = function (sel) { return variants.find(function (v) { return sel.every(function (val, i) { return v["option" + (i + 1)] === val; }); }); };
      var paint = function () {
        var sel = selected(), v = find(sel);
        var bundleCard = box.querySelector("[data-bundle-card]"), bundleOn = !!(bundleCard && bundleCard.querySelector("input").checked);
        if (bundleCard) bundleCard.classList.toggle("is-on", bundleOn);
        if (bundleOn) {
          var ids = bundleCard.getAttribute("data-bundle-ids"), bp = parseInt(bundleCard.getAttribute("data-bundle-price"), 10), bc = parseInt(bundleCard.getAttribute("data-bundle-compare"), 10);
          fields.forEach(function (f) { f.querySelectorAll(".vopt__pill").forEach(function (pill) { if (!pill.hasAttribute("data-bundle-card")) pill.classList.remove("is-on"); }); });
          if (form) { form.setAttribute("data-bundle", ids); var id0 = form.querySelector("[name=id]"); if (id0) id0.value = ids.split(",")[0]; var b0 = form.querySelector("[type=submit]"); if (b0) { b0.disabled = false; var sp0 = b0.querySelector("span"); if (sp0) { if (!sp0.getAttribute("data-label")) sp0.setAttribute("data-label", sp0.innerHTML); sp0.innerHTML = bundleCard.getAttribute("data-bundle-cta") || sp0.getAttribute("data-label"); } } }
          document.querySelectorAll("[data-p-price]").forEach(function (el) { el.textContent = money(bp); });
          document.querySelectorAll("[data-p-compare]").forEach(function (el) { if (bc > bp) { el.textContent = money(bc); el.hidden = false; } else el.hidden = true; });
          document.querySelectorAll("[data-cta-price]").forEach(function (el) { el.textContent = money(bp); });
          return;
        }
        if (form) form.removeAttribute("data-bundle");
        fields.forEach(function (f, i) {
          var val = f.querySelector("[data-vopt-value]"); if (val) val.textContent = sel[i] || "";
          f.querySelectorAll(".vopt__pill").forEach(function (pill) {
            if (pill.hasAttribute("data-bundle-card")) return;
            var input = pill.querySelector("input"); pill.classList.toggle("is-on", input.checked);
            var probe = sel.slice(); probe[i] = input.value; var pv = find(probe); pill.classList.toggle("is-off", !pv || !pv.available);
          });
        });
        if (!v) return;
        if (form) { var id = form.querySelector("[name=id]"); if (id) id.value = v.id; var btn = form.querySelector("[type=submit]"); if (btn) { btn.disabled = !v.available; var sp = btn.querySelector("span"); if (sp) { if (!sp.getAttribute("data-label")) sp.setAttribute("data-label", sp.innerHTML); sp.innerHTML = v.available ? sp.getAttribute("data-label") : "Sold out"; } } }
        document.querySelectorAll("[data-p-price]").forEach(function (el) { el.textContent = money(v.price); });
        document.querySelectorAll("[data-p-compare]").forEach(function (el) { if (v.compare_at_price && v.compare_at_price > v.price) { el.textContent = money(v.compare_at_price); el.hidden = false; } else el.hidden = true; });
        document.querySelectorAll("[data-cta-price]").forEach(function (el) { el.textContent = money(v.price); });
        var mediaId = v.featured_media ? v.featured_media.id : (v.featured_image ? v.featured_image.id : null);
        if (mediaId) { var thumb = document.querySelector('[data-gallery-thumb][data-media-id="' + mediaId + '"]'); if (thumb && thumb.getAttribute("aria-selected") !== "true") thumb.click(); }
        try { var url = new URL(window.location.href); url.searchParams.set("variant", v.id); history.replaceState(null, "", url.toString()); } catch (e) {}
      };
      box.addEventListener("change", paint); paint();
    });
  };
  init(); document.addEventListener("shopify:section:load", function (e) { init(e.target); });
  if (window.AL_SCOPE_INITS) window.AL_SCOPE_INITS.push(init);
})();

/* Product page: quantity deal cards (set the quantity + price), sold bar animation. */
(function () {
  var money = function (cents) { var el = document.querySelector("[data-p-price]"); var sample = el ? el.textContent.trim() : "$0.00"; var v = (cents / 100).toFixed(2); var comma = /\d,\d\d(?!\d)/.test(sample); if (comma) v = v.replace(".", ","); var m = sample.match(/^([^\d]*)[\d.,\s]+([^\d]*)$/); return (m ? m[1] : "") + v + (m ? m[2] : ""); };
  var initDeal = function (scope) {
    (scope || document).querySelectorAll("[data-deal]").forEach(function (box) {
      if (box.getAttribute("data-init")) return; box.setAttribute("data-init", "1");
      var wrap = box.closest(".product");
      var form = wrap ? wrap.querySelector("form[data-type=add-to-cart-form]") : document.getElementById("primary-cta");
      var apply = function (card) {
        box.querySelectorAll("[data-deal-card]").forEach(function (c) { c.classList.toggle("is-on", c === card); });
        var qty = parseInt(card.getAttribute("data-deal-qty"), 10) || 1, p = parseInt(card.getAttribute("data-price"), 10), c = parseInt(card.getAttribute("data-compare"), 10) || 0;
        if (form) { var q = form.querySelector("[name=quantity]"); if (q) q.value = qty; }
        if (isNaN(p)) return;
        document.querySelectorAll("[data-p-price]").forEach(function (el) { el.textContent = money(p); });
        document.querySelectorAll("[data-p-compare]").forEach(function (el) { if (c > p) { el.textContent = money(c); el.hidden = false; } else el.hidden = true; });
        document.querySelectorAll("[data-cta-price]").forEach(function (el) { el.textContent = money(p); });
      };
      box.addEventListener("change", function (e) { var card = e.target.closest("[data-deal-card]"); if (card) apply(card); });
      var on = box.querySelector("[data-deal-card] input:checked"); if (on) apply(on.closest("[data-deal-card]"));
    });
  };
  var initSold = function (scope) {
    (scope || document).querySelectorAll("[data-sold]").forEach(function (el) {
      if (el.getAttribute("data-init")) return; el.setAttribute("data-init", "1");
      var target = Math.max(0, Math.min(100, parseInt(el.getAttribute("data-sold"), 10) || 0)), num = el.querySelector("[data-sold-num]");
      el.style.setProperty("--sold-pct", target + "%");
      var run = function () {
        el.classList.add("is-in");
        if (!num || (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches)) return;
        var t0 = null;
        var step = function (ts) { if (!t0) t0 = ts; var k = Math.min(1, (ts - t0) / 1400); var e = 1 - Math.pow(1 - k, 3); num.textContent = String(Math.round(target * e)); if (k < 1) requestAnimationFrame(step); };
        num.textContent = "0"; requestAnimationFrame(step);
      };
      if ("IntersectionObserver" in window) { var io = new IntersectionObserver(function (entries) { if (entries[0].isIntersecting) { io.disconnect(); run(); } }, { threshold: 0.4 }); io.observe(el); } else run();
    });
  };
  var init = function (scope) { initDeal(scope); initSold(scope); };
  init(document); (window.AL_SCOPE_INITS = window.AL_SCOPE_INITS || []).push(init);
})();
