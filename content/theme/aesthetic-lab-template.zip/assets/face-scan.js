/* Aesthetic Lab face scan. Guided capture (front + 45°), live checks (light, distance, centering, chin level),
   on-device landmarks (MediaPipe via CDN), measurement overlay drawn on the user's own face.
   Nothing is uploaded: frames stay in the browser; the result is kept in localStorage only.
   Usage: window.AL_FACE_SCAN.mount(containerElement, { onDone: fn(result), onSkip: fn }) */
(function () {
  var CDN = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14";
  var MODEL = "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task";
  var KEY = "aestheticScan";
  var pad = function (n) { return String(n).padStart(2, "0"); };
  var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); };

  var TEMPLATE = function (o) {
    return '' +
      '<div class="fs" data-fs data-state="idle" data-pose="front">' +
        '<div class="fs__top"><span class="fs__count" data-fs-count>Scan · 01/02</span><span class="fs__local">' + o.localLabel + '</span></div>' +
        '<p class="fs__title" data-fs-title>Look straight at the camera</p>' +
        '<p class="fs__hint" data-fs-hint>Even light, phone at eye level, neutral face.</p>' +
        '<div class="fs__stage">' +
          '<video class="fs__video" data-fs-video autoplay playsinline muted hidden></video>' +
          '<canvas class="fs__shot" data-fs-shot hidden></canvas>' +
          '<svg class="fs__guide" viewBox="0 0 300 400" preserveAspectRatio="none" aria-hidden="true"><defs><mask id="fsMask"><rect width="300" height="400" fill="#fff"/><ellipse cx="150" cy="190" rx="98" ry="132" fill="#000"/></mask></defs><rect width="300" height="400" fill="rgba(0,0,0,.42)" mask="url(#fsMask)"/><ellipse class="fs__oval" data-fs-oval cx="150" cy="190" rx="98" ry="132" fill="none" stroke="rgba(255,255,255,.85)" stroke-width="2" stroke-dasharray="6 5"/><line x1="150" y1="58" x2="150" y2="322" stroke="rgba(255,255,255,.35)" stroke-width="1"/><line x1="52" y1="190" x2="248" y2="190" stroke="rgba(255,255,255,.35)" stroke-width="1"/></svg>' +
          '<div class="fs__ring" aria-hidden="true"><span data-fs-ring></span></div>' +
          '<div class="fs__hud" data-fs-hud hidden><p class="fs__msg" data-fs-msg>Starting…</p><ul class="fs__checks"><li data-fs-c="light">Light</li><li data-fs-c="dist">Distance</li><li data-fs-c="center">Centered</li><li data-fs-c="level">Chin level</li></ul></div>' +
          '<div class="fs__empty" data-fs-empty><span class="fs__cam">' + o.camIcon + '</span><p>' + o.introText + '</p></div>' +
          '<div class="fs__flash" aria-hidden="true"></div>' +
        '</div>' +
        '<div class="fs__actions">' +
          '<button type="button" class="btn btn--primary btn--lg btn--full" data-fs-start><span>' + o.startLabel + '</span></button>' +
          '<button type="button" class="btn btn--primary btn--lg btn--full" data-fs-capture hidden><span>Take photo</span></button>' +
          '<div class="fs__row" data-fs-review hidden><button type="button" class="btn btn--secondary btn--lg" data-fs-retake><span>Retake</span></button><button type="button" class="btn btn--primary btn--lg" data-fs-use><span>Use this photo →</span></button></div>' +
        '</div>' +
        '<div class="fs__foot"><label class="fs__import"><span>' + o.importLabel + '</span><input type="file" accept="image/*" data-fs-file hidden></label><button type="button" class="fs__skip" data-fs-skip>' + o.skipLabel + '</button></div>' +
      '</div>';
  };

  /* ---------- geometry helpers ---------- */
  var dist = function (a, b) { return Math.hypot(a.x - b.x, a.y - b.y); };
  var angleAt = function (p, a, b) { var v1 = { x: a.x - p.x, y: a.y - p.y }, v2 = { x: b.x - p.x, y: b.y - p.y }; var d = (v1.x * v2.x + v1.y * v2.y) / (Math.hypot(v1.x, v1.y) * Math.hypot(v2.x, v2.y) || 1); return Math.acos(Math.max(-1, Math.min(1, d))) * 180 / Math.PI; };
  var deg = function (a, b) { return Math.atan2(b.y - a.y, b.x - a.x) * 180 / Math.PI; };

  /* Metrics from 468 MediaPipe landmarks (normalized coords, image space). */
  var metrics = function (f, mirrored) {
    var P = function (i) { return { x: f[i].x, y: f[i].y }; };
    var top = P(10), chin = P(152), glab = P(9), subn = P(2);
    var L = { outer: P(33), inner: P(133), cheek: P(234), jaw: P(58), mouth: P(61), ramus: P(132) };
    var R = { outer: P(263), inner: P(362), cheek: P(454), jaw: P(288), mouth: P(291), ramus: P(361) };
    var mid = { x: (top.x + chin.x) / 2, y: (top.y + chin.y) / 2 };
    var faceW = dist(L.cheek, R.cheek), faceH = dist(top, chin);
    // symmetry: difference of left/right distances to the midline, for eyes and mouth
    var midX = function (y) { var t = (y - top.y) / ((chin.y - top.y) || 1); return top.x + (chin.x - top.x) * t; };
    var eyeAsym = Math.abs((midX(L.outer.y) - L.outer.x) - (R.outer.x - midX(R.outer.y))) / faceW;
    var mouthAsym = Math.abs((midX(L.mouth.y) - L.mouth.x) - (R.mouth.x - midX(R.mouth.y))) / faceW;
    var symmetry = Math.max(0, Math.min(100, Math.round(100 - ((eyeAsym + mouthAsym) / 2) * 400)));
    // facial thirds
    var upper = dist(top, glab), middle = dist(glab, subn), lower = dist(subn, chin), tot = upper + middle + lower || 1;
    var thirds = [upper / tot, middle / tot, lower / tot].map(function (v) { return Math.round(v * 100); });
    // canthal tilt (positive = outer corner higher than inner corner); image y grows downward
    var tiltL = -deg(L.inner, L.outer), tiltR = deg(R.inner, R.outer);
    var canthal = Math.round(((tiltL + tiltR) / 2) * 10) / 10;
    // gonial angle at each jaw corner between the ramus (towards the ear) and the chin
    var gonL = angleAt(L.jaw, L.ramus, chin), gonR = angleAt(R.jaw, R.ramus, chin);
    var gonial = Math.round((gonL + gonR) / 2);
    // jaw width vs cheekbone width, face height vs width
    var jawRatio = Math.round(dist(L.jaw, R.jaw) / (faceW || 1) * 100) / 100;
    var faceRatio = Math.round(faceH / (faceW || 1) * 100) / 100;
    var roll = deg(L.outer, R.outer); if (mirrored) roll = -roll;
    return { symmetry: symmetry, thirds: thirds, canthal: canthal, gonial: gonial, jawRatio: jawRatio, faceRatio: faceRatio, roll: Math.round(roll * 10) / 10, faceW: faceW, cx: mid.x, cy: mid.y };
  };

  /* Draw the measurement overlay on a canvas that already holds the photo. */
  var draw = function (ctx, f, w, h, pose) {
    var P = function (i) { return { x: f[i].x * w, y: f[i].y * h }; };
    var s = Math.max(1, w / 360);
    ctx.save(); ctx.lineCap = "round"; ctx.lineJoin = "round";
    var line = function (a, b, color, width, dash) { ctx.beginPath(); ctx.setLineDash(dash || []); ctx.strokeStyle = color; ctx.lineWidth = width * s; ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); ctx.setLineDash([]); };
    var dot = function (p, color, r) { ctx.beginPath(); ctx.fillStyle = color; ctx.arc(p.x, p.y, (r || 2.4) * s, 0, Math.PI * 2); ctx.fill(); };
    var label = function (p, text, dx, dy) { ctx.font = (10.5 * s) + "px Inter, system-ui, sans-serif"; var tw = ctx.measureText(text).width; var x = p.x + (dx || 0) * s, y = p.y + (dy || 0) * s; ctx.fillStyle = "rgba(20,28,32,.72)"; ctx.beginPath(); ctx.roundRect ? ctx.roundRect(x - 5 * s, y - 11 * s, tw + 10 * s, 15 * s, 4 * s) : ctx.rect(x - 5 * s, y - 11 * s, tw + 10 * s, 15 * s); ctx.fill(); ctx.fillStyle = "#fff"; ctx.fillText(text, x, y); };
    var white = "rgba(255,255,255,.92)", mint = "#7fe3c1", gold = "#ffd56b";
    var top = P(10), chin = P(152), glab = P(9), subn = P(2);
    var jawIdx = [234, 93, 132, 58, 172, 136, 150, 149, 176, 148, 152, 377, 400, 378, 379, 365, 397, 288, 361, 323, 454];
    // jawline
    ctx.beginPath(); ctx.strokeStyle = mint; ctx.lineWidth = 2.2 * s;
    jawIdx.forEach(function (i, k) { var p = P(i); if (k === 0) ctx.moveTo(p.x, p.y); else ctx.lineTo(p.x, p.y); }); ctx.stroke();
    if (pose === "front") {
      // midline + thirds
      line(top, chin, white, 1.2, [6 * s, 5 * s]);
      var xl = Math.min(P(234).x, P(454).x) - 14 * s, xr = Math.max(P(234).x, P(454).x) + 14 * s;
      [top, glab, subn, chin].forEach(function (p) { line({ x: xl, y: p.y }, { x: xr, y: p.y }, white, 1, [3 * s, 4 * s]); });
      // canthal tilt
      line(P(133), P(33), gold, 2); line(P(362), P(263), gold, 2);
      [33, 133, 263, 362].forEach(function (i) { dot(P(i), gold); });
      // gonial angle markers
      [58, 288].forEach(function (i) { dot(P(i), mint, 3.2); });
      line(P(58), P(132), mint, 1.2, [4 * s, 3 * s]); line(P(288), P(361), mint, 1.2, [4 * s, 3 * s]);
      label({ x: xl, y: (top.y + glab.y) / 2 }, "upper", 6, 4); label({ x: xl, y: (glab.y + subn.y) / 2 }, "middle", 6, 4); label({ x: xl, y: (subn.y + chin.y) / 2 }, "lower", 6, 4);
      label(P(263), "canthal tilt", 8, -8); label(P(288), "gonial angle", 8, 14); label(chin, "jawline", 10, 18);
    } else {
      [58, 288].forEach(function (i) { dot(P(i), mint, 3.2); });
      line(P(58), P(132), mint, 1.2, [4 * s, 3 * s]); line(P(288), P(361), mint, 1.2, [4 * s, 3 * s]);
      label(chin, "jawline", 10, 18); label(P(58), "gonial angle", 8, 14);
    }
    ctx.restore();
  };

  var mount = function (container, opts) {
    opts = opts || {};
    var poses = [
      { id: "front", title: opts.frontTitle || "Look straight at the camera", hint: "Hold still. The photo is taken for you when everything is green." },
      { id: "angle", title: opts.angleTitle || "Now turn your head 45° to the left", hint: "Keep your chin level. Stop when the ring fills." }
    ];
    container.innerHTML = TEMPLATE({
      localLabel: opts.localLabel || "On-device · nothing uploaded",
      introText: opts.introText || "Two photos: front, then 45°. Your phone measures your face itself. Nothing is sent anywhere.",
      startLabel: opts.startLabel || "Start the scan", importLabel: opts.importLabel || "Import a photo instead", skipLabel: opts.skipLabel || "Skip",
      camIcon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/></svg>'
    });
    var root = container.querySelector("[data-fs]");
    var q = function (sel) { return root.querySelector(sel); };
    var video = q("[data-fs-video]"), shot = q("[data-fs-shot]"), hud = q("[data-fs-hud]"), msg = q("[data-fs-msg]"), ring = q("[data-fs-ring]"), empty = q("[data-fs-empty]");
    var bStart = q("[data-fs-start]"), bCap = q("[data-fs-capture]"), review = q("[data-fs-review]"), bRetake = q("[data-fs-retake]"), bUse = q("[data-fs-use]"), file = q("[data-fs-file]"), bSkip = q("[data-fs-skip]");
    var idx = 0, shots = {}, stream = null, tracker = null, trackerFailed = false, loop = null, hold = 0, lastTs = 0, capturing = false, attempts = 0, pending = null, imgTs = 1;
    var checks = { light: false, dist: false, center: false, level: false };
    var setCheck = function (k, v) { checks[k] = v; var el = q('[data-fs-c="' + k + '"]'); if (el) el.setAttribute("data-ok", v ? "true" : "false"); };
    var setState = function (st) {
      root.setAttribute("data-state", st);
      video.hidden = st !== "live"; shot.hidden = st !== "shot"; empty.hidden = st !== "idle"; hud.hidden = st !== "live";
      bStart.hidden = st !== "idle"; bCap.hidden = !(st === "live" && (trackerFailed || !tracker)); review.hidden = st !== "shot";
    };
    var renderPose = function () {
      var p = poses[idx]; hold = 0; attempts = 0;
      q("[data-fs-count]").textContent = "Scan · " + pad(idx + 1) + "/" + pad(poses.length);
      q("[data-fs-title]").textContent = p.title; q("[data-fs-hint]").textContent = p.hint;
      root.setAttribute("data-pose", p.id); if (ring) ring.style.setProperty("--p", 0);
    };
    var stopLoop = function () { if (loop) cancelAnimationFrame(loop); loop = null; };
    var stop = function () { stopLoop(); if (stream) { stream.getTracks().forEach(function (t) { t.stop(); }); stream = null; } };
    var flash = function () { root.classList.add("is-flash"); setTimeout(function () { root.classList.remove("is-flash"); }, 320); };

    var luminance = function (src, sw, sh) {
      var c = document.createElement("canvas"), w = 64, h = Math.max(1, Math.round(64 * sh / sw)); c.width = w; c.height = h;
      var ctx = c.getContext("2d"); ctx.drawImage(src, 0, 0, w, h); var d = ctx.getImageData(Math.round(w * 0.25), Math.round(h * 0.2), Math.round(w * 0.5), Math.round(h * 0.55)).data, sum = 0, n = d.length / 4;
      for (var i = 0; i < d.length; i += 4) sum += 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
      return sum / n;
    };
    var sharpness = function (src, sw, sh) {
      var c = document.createElement("canvas"), w = 96, h = Math.max(1, Math.round(96 * sh / sw)); c.width = w; c.height = h;
      var ctx = c.getContext("2d"); ctx.drawImage(src, 0, 0, w, h); var d = ctx.getImageData(0, 0, w, h).data, g = new Float32Array(w * h);
      for (var i = 0; i < w * h; i++) g[i] = 0.299 * d[i * 4] + 0.587 * d[i * 4 + 1] + 0.114 * d[i * 4 + 2];
      var lap = 0, n = 0; for (var y = 1; y < h - 1; y++) for (var x = 1; x < w - 1; x++) { var k = y * w + x; var v = 4 * g[k] - g[k - 1] - g[k + 1] - g[k - w] - g[k + w]; lap += v * v; n++; }
      return lap / n;
    };

    var loadTracker = function () {
      if (tracker || trackerFailed) return Promise.resolve(tracker);
      if (msg) msg.textContent = "Preparing the scanner…";
      return import(CDN + "/vision_bundle.mjs").then(function (mod) {
        return mod.FilesetResolver.forVisionTasks(CDN + "/wasm").then(function (fs) {
          return mod.FaceLandmarker.createFromOptions(fs, { baseOptions: { modelAssetPath: MODEL, delegate: "GPU" }, runningMode: "VIDEO", numFaces: 1 });
        });
      }).then(function (lm) { tracker = lm; return lm; }).catch(function () { trackerFailed = true; if (msg) msg.textContent = "Automatic scan unavailable here. Frame your face and press the button."; setState("live"); return null; });
    };
    var landmarksOf = function (src) {
      if (!tracker) return null;
      try { var res = tracker.detectForVideo(src, performance.now() + (imgTs++)); return res && res.faceLandmarks && res.faceLandmarks[0] || null; } catch (e) { return null; }
    };
    var measureLive = function () {
      if (!video.videoWidth) return null;
      var now = performance.now(); if (now - lastTs < 70) return undefined; lastTs = now;
      var f = landmarksOf(video); if (!f) return null;
      var a = f[234], b = f[454], nose = f[1];
      var width = Math.abs(b.x - a.x);
      var r = (nose.x - Math.min(a.x, b.x)) / (width || 1); var mirrored = b.x < a.x; if (mirrored) r = 1 - r;
      var roll = Math.abs(Math.atan2(f[263].y - f[33].y, f[263].x - f[33].x) * 180 / Math.PI);
      var pitch = (f[152].y - f[10].y); // face height ratio, used with nose to detect chin up/down roughly
      var chinLevel = Math.abs((f[1].y - f[10].y) / (pitch || 1) - 0.52) < 0.09;
      return { width: width, r: r, roll: roll, cx: nose.x, cy: nose.y, level: roll < 7 && chinLevel };
    };
    var target = function (pose, r) {
      if (pose === "front") return { ok: r > 0.42 && r < 0.58, dir: r <= 0.42 ? "Turn slightly to the right" : r >= 0.58 ? "Turn slightly to the left" : "Hold still…" };
      return { ok: r > 0.68 && r < 0.9, dir: r <= 0.68 ? "Keep turning to the left" : r >= 0.9 ? "A little less, come back" : "Hold it there…" };
    };
    var lightTick = 0, lightOk = true;
    var tick = function () {
      loop = requestAnimationFrame(tick);
      if (capturing) return;
      if ((lightTick++ % 6) === 0 && video.videoWidth) { var lum = luminance(video, video.videoWidth, video.videoHeight); lightOk = lum > 62 && lum < 210; setCheck("light", lightOk); if (!lightOk) { hold = 0; msg.textContent = lum <= 62 ? "Too dark. Face a window." : "Too bright. Step out of direct light."; if (ring) ring.style.setProperty("--p", 0); return; } }
      if (!lightOk) return;
      var m = measureLive(); if (m === undefined) return;
      if (!m) { hold = 0; setCheck("dist", false); setCheck("center", false); setCheck("level", false); msg.textContent = "Center your face in the oval"; if (ring) ring.style.setProperty("--p", 0); return; }
      var distOk = m.width > 0.28 && m.width < 0.62; setCheck("dist", distOk);
      var centerOk = m.cx > 0.36 && m.cx < 0.64 && m.cy > 0.3 && m.cy < 0.62; setCheck("center", centerOk);
      setCheck("level", m.level);
      var t = target(poses[idx].id, m.r);
      var ok = distOk && centerOk && t.ok && (poses[idx].id === "front" ? m.level : true);
      msg.textContent = !distOk ? (m.width <= 0.28 ? "Move a little closer" : "Move back a little") : !centerOk ? "Center your face in the oval" : (poses[idx].id === "front" && !m.level) ? "Keep your chin level" : t.dir;
      if (ok) hold += 1; else hold = Math.max(0, hold - 2);
      var need = 14; if (ring) ring.style.setProperty("--p", Math.min(1, hold / need));
      if (hold >= need) { capturing = true; hold = 0; setTimeout(function () { autoCapture(); capturing = false; }, 60); }
    };
    var startLoop = function () { stopLoop(); lastTs = 0; hold = 0; if (tracker) loop = requestAnimationFrame(tick); };

    var frameToCanvas = function (src, sw, sh) {
      var max = 900, r = Math.min(1, max / Math.max(sw, sh)), c = document.createElement("canvas");
      c.width = Math.round(sw * r); c.height = Math.round(sh * r);
      var ctx = c.getContext("2d");
      if (src === video) { ctx.translate(c.width, 0); ctx.scale(-1, 1); } // un-mirror the selfie
      ctx.drawImage(src, 0, 0, c.width, c.height); return c;
    };
    var analyse = function (canvas, pose) {
      var f = landmarksOf(canvas), rec = { url: canvas.toDataURL("image/jpeg", 0.85), pose: pose };
      if (f) {
        rec.metrics = metrics(f, false);
        var ann = document.createElement("canvas"); ann.width = canvas.width; ann.height = canvas.height;
        var ctx = ann.getContext("2d"); ctx.drawImage(canvas, 0, 0); draw(ctx, f, ann.width, ann.height, pose);
        rec.annotated = ann.toDataURL("image/jpeg", 0.85); rec.landmarks = true;
      }
      return rec;
    };
    var accept = function (rec) {
      shots[poses[idx].id] = rec;
      if (idx < poses.length - 1) { idx++; renderPose(); pending = null; setState(stream ? "live" : "idle"); if (stream && tracker) startLoop(); }
      else finish();
    };
    var autoCapture = function () {
      if (!video.videoWidth) return;
      var c = frameToCanvas(video, video.videoWidth, video.videoHeight);
      var lum = luminance(c, c.width, c.height), sh = sharpness(c, c.width, c.height), ok = lum > 62 && lum < 210 && sh > 30;
      attempts++;
      if (!ok && attempts < 3) { msg.textContent = lum <= 62 ? "Too dark. Face a window and try again." : sh <= 30 ? "A bit blurry. Hold still." : "Too bright. Step out of direct light."; hold = 0; return; }
      flash(); accept(analyse(c, poses[idx].id));
    };
    var showReview = function (canvas) {
      stopLoop();
      var lum = luminance(canvas, canvas.width, canvas.height), sh = sharpness(canvas, canvas.width, canvas.height);
      var f = landmarksOf(canvas);
      var dark = lum <= 62, blurry = sh <= 30;
      if (dark || !f) {
        // an instrument rejects bad input
        shot.width = canvas.width; shot.height = canvas.height; shot.getContext("2d").drawImage(canvas, 0, 0);
        setState("shot"); review.hidden = false; bUse.hidden = true;
        q("[data-fs-title]").textContent = dark ? "Too dark. Face a window and retake." : "No face detected. Retake, closer and centered.";
        pending = null; return;
      }
      bUse.hidden = false;
      var rec = analyse(canvas, poses[idx].id);
      shot.width = canvas.width; shot.height = canvas.height;
      var img = new Image(); img.onload = function () { shot.getContext("2d").drawImage(img, 0, 0); }; img.src = rec.annotated || rec.url;
      q("[data-fs-title]").textContent = blurry ? "A bit blurry. Retake if you can." : "Looks good";
      pending = rec; setState("shot"); flash();
    };
    var finish = function () {
      stop();
      var result = { takenAt: new Date().toISOString(), front: shots.front || null, angle: shots.angle || null, metrics: shots.front && shots.front.metrics || null, local: true };
      try { localStorage.setItem(KEY, JSON.stringify(result)); } catch (e) {}
      try { var ph = {}; if (shots.front) ph.front = { url: shots.front.url }; if (shots.angle) ph.left = { url: shots.angle.url }; if (Object.keys(ph).length) localStorage.setItem("aestheticPhotos", JSON.stringify({ takenAt: result.takenAt, shots: ph })); } catch (e) {}
      if (opts.onDone) opts.onDone(result);
    };

    bStart.addEventListener("click", function () {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { empty.querySelector("p").textContent = "No camera here. Import a photo instead."; return; }
      navigator.mediaDevices.getUserMedia({ video: { facingMode: "user", width: { ideal: 1280 }, height: { ideal: 1600 } }, audio: false })
        .then(function (s) { stream = s; video.srcObject = s; setState("live"); msg.textContent = "Starting…"; return loadTracker(); })
        .then(function () { if (stream) { setState("live"); startLoop(); } })
        .catch(function () { empty.querySelector("p").textContent = "Camera access was refused. Import a photo instead."; });
    });
    bCap.addEventListener("click", function () { if (video.videoWidth) showReview(frameToCanvas(video, video.videoWidth, video.videoHeight)); });
    file.addEventListener("change", function () {
      var f = file.files && file.files[0]; if (!f) return;
      var img = new Image(); img.onload = function () {
        var c = document.createElement("canvas"), max = 900, r = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight)); c.width = Math.round(img.naturalWidth * r); c.height = Math.round(img.naturalHeight * r); c.getContext("2d").drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(img.src);
        loadTracker().then(function () { showReview(c); });
      }; img.src = URL.createObjectURL(f); file.value = "";
    });
    bRetake.addEventListener("click", function () { pending = null; q("[data-fs-title]").textContent = poses[idx].title; setState(stream ? "live" : "idle"); if (stream && tracker) startLoop(); });
    bUse.addEventListener("click", function () { if (!pending) return; var rec = pending; pending = null; accept(rec); });
    bSkip.addEventListener("click", function () { stop(); if (opts.onSkip) opts.onSkip(); });
    renderPose(); setState("idle");
    return { destroy: stop };
  };

  window.AL_FACE_SCAN = { mount: mount, KEY: KEY, load: function () { try { return JSON.parse(localStorage.getItem(KEY) || "null"); } catch (e) { return null; } } };
})();
